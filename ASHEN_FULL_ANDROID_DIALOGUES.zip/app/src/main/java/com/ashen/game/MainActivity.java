package com.ashen.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;
import java.io.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        setContentView(new GameView(this));
    }
}

class GameView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint px = new Paint();
    final Random rng = new Random();
    final SharedPreferences save;
    ToneGenerator tone;

    Bitmap heroIdle, heroAttack, heroHurt, heroDeath, knight, knightAttack, witch, witchAttack, fireball, shadow, blood, arrow;
    float W,H,ui;
    long last;

    // Screens
    static final int MENU=0, STORY=1, MAP=2, ROOM=3, REWARD=4, SHOP=5, BOSS=6, PAUSE=7, GAMEOVER=8, VICTORY=9, ARCHIVE=10, EQUIP=11, DIALOGUE=12;
    int screen=MENU;

    // Campaign
    int chapter=0, room=0, roomsPerChapter=4, totalBossesDefeated=0;
    int coins=0, kills=0, deaths=0;
    String storyTitle="";
    boolean bossIntro=false;
    boolean bossDeathPending=false;
    boolean bossLowShown=false;
    int bossPhase=1;
    ArrayList<String> dialogueLines=new ArrayList<>();
    int dialogueIndex=0;
    String dialogueSpeaker="";
    String dialogueMoment="";

    // Player
    float x,y,hp,maxHp,stamina,maxStamina,energy,maxEnergy;
    float dirX=0,dirY=1;
    boolean moveTouch=false; int moveId=-1; float joyX,joyY;
    long attackUntil=0,spellUntil=0,dodgeUntil=0,parryUntil=0,invulnUntil=0,hurtUntil=0;
    int combo=0; long comboUntil=0;
    int weapon=0, spell=0;
    boolean[] relics=new boolean[8];
    int weaponLevel=0, spellLevel=0;

    // Room
    int roomType=0; // 0 combat, 1 elite, 2 treasure, 3 lore, 4 shop, 5 boss
    boolean roomCleared=false;
    ArrayList<Enemy> enemies=new ArrayList<>();
    ArrayList<Projectile> projectiles=new ArrayList<>();
    ArrayList<Fx> fx=new ArrayList<>();
    ArrayList<Loot> loot=new ArrayList<>();
    long roomTimer=0, nextSpawn=0, flash=0;

    // Touch action buttons: attack,dodge,spell,parry,interact
    boolean[] pressed=new boolean[5];
    int[] buttonPointerId={-1,-1,-1,-1,-1};

    final String[] chapters={"ПЕПЕЛЬНЫЕ КАТАКОМБЫ","ЗАТОПЛЕННАЯ ЧАСОВНЯ","ЧЁРНАЯ КУЗНИЦА","САД БЕЗ СВЕТА","ТРОН ПУСТОТЫ"};
    final String[] bossNames={"КАЭЛЬ, ПОСЛЕДНИЙ СТРАЖ","МАТЬ УГЛЕЙ","ВАРГАН, ЖЕЛЕЗНЫЙ ПАЛАЧ","ИЛЬРА, САДОВНИЦА ТИШИНЫ","АСТЕР, ПЕРВЫЙ ПЕПЕЛ"};
    final String[] bossLore={
            "Когда-то Каэль охранял дверь к Пустоте. Он забыл, кого защищал.",
            "Мать Углей питается воспоминаниями погибших и не умеет отпускать мёртвых.",
            "Варган ковал цепи для тех, кто пытался бежать из мира Пепла.",
            "Ильра превратила души во цветы, чтобы остановить течение времени.",
            "Астер — тот, кто первым услышал голос Пустоты. Он зовёт героя по имени."
    };

    final String[] weaponNames={"ПЕПЕЛЬНЫЙ КЛИНОК","КОПЬЁ ЗВОНА","КОСА МОЛЧАНИЯ","КРИВОЙ МЕЧ","КЛИНОК ЗАРИ","ПАЛАЧ ПЕПЛА"};
    final int[] weaponDmg={34,28,45,38,32,52};
    final float[] weaponRange={94,122,110,104,98,116};
    final float[] weaponCd={270,340,420,300,230,500};
    final String[] spellNames={"ОГНЕННЫЙ ШАР","ЛЕДЯНОЙ ОСКОЛОК","ЦЕПЬ ТЕНИ","ГРОМОВОЙ ИМПУЛЬС","МЕТЕОР","ПЕПЕЛЬНОЕ СЕРДЦЕ"};
    final int[] spellCost={24,28,32,38,50,42};
    final int[] spellDmg={44,54,36,72,120,0};

    GameView(Context c){
        super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); px.setFilterBitmap(false);
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));
        heroIdle=load(c,R.drawable.hero_idle); heroAttack=load(c,R.drawable.hero_attack); heroHurt=load(c,R.drawable.hero_hurt); heroDeath=load(c,R.drawable.hero_death);
        knight=load(c,R.drawable.enemy_knight); knightAttack=load(c,R.drawable.enemy_knight_attack); witch=load(c,R.drawable.enemy_witch); witchAttack=load(c,R.drawable.enemy_witch_attack);
        fireball=load(c,R.drawable.fireball); shadow=load(c,R.drawable.shadow); blood=load(c,R.drawable.blood); arrow=load(c,R.drawable.arrow);
        save=c.getSharedPreferences("ashen_full",Context.MODE_PRIVATE);
        loadDialogue();
        loadSave();
        try{tone=new ToneGenerator(AudioManager.STREAM_MUSIC,55);}catch(Exception ignored){}
        last=System.nanoTime(); post(tick);
    }
    Bitmap load(Context c,int id){return BitmapFactory.decodeResource(c.getResources(),id);}
    float S(){return Math.min(W/1080f,H/1920f);}
    float sx(float v){return v*S();}
    float sy(float v){return v*S();}
    void loadDialogue(){
        try{
            InputStream in=getContext().getAssets().open("story_ru.txt");
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            String line;
            while((line=br.readLine())!=null) dialogueLines.add(line);
            br.close();
        }catch(Exception e){
            dialogueLines.clear();
        }
    }
    String[] getDialogue(String key){
        ArrayList<String> out=new ArrayList<>();
        String prefix=key+"|";
        for(String line:dialogueLines) if(line.startsWith(prefix)) out.add(line.substring(prefix.length()));
        return out.toArray(new String[0]);
    }
    void startDialogue(String key){
        String[] lines=getDialogue(key);
        if(lines.length==0)return;
        dialogueLinesCache=lines; dialogueIndex=0; dialogueMoment=key;
        String[] first=lines[0].split("\\|",2);
        dialogueSpeaker=first.length>1?first[0]:"";
        screen=DIALOGUE;
        saveAll(); invalidate();
    }
    String[] dialogueLinesCache=new String[0];
    void nextDialogue(){
        dialogueIndex++;
        if(dialogueIndex>=dialogueLinesCache.length){
            finishDialogue(); return;
        }
        String[] parts=dialogueLinesCache[dialogueIndex].split("\\|",2);
        dialogueSpeaker=parts.length>1?parts[0]:"";
        invalidate();
    }
    void finishDialogue(){
        String key=dialogueMoment;
        dialogueLinesCache=new String[0]; dialogueIndex=0; dialogueSpeaker=""; dialogueMoment="";
        if(key.startsWith("boss_pre_")){ screen=BOSS; bossIntro=false; return; }
        if(key.startsWith("boss_phase2_")){ screen=BOSS; bossPhase=2; return; }
        if(key.startsWith("boss_low_")){ screen=BOSS; return; }
        if(key.startsWith("boss_death_")){
            bossDeathPending=false;
            if(chapter>=4){ screen=VICTORY; } else { chapter++; room=0; screen=REWARD; }
            saveAll(); return;
        }
        screen=BOSS;
    }
    void drawDialogue(Canvas c){
        bg(c);
        drawArenaDecor(c);
        for(Enemy e:enemies) drawEnemy(c,e);
        drawPlayer(c);
        panel(c,70,820,1010,1450,Color.argb(238,12,10,17));
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sx(3)); p.setColor(Color.rgb(130,100,110));
        c.drawRoundRect(sx(70),sy(820),sx(1010),sy(1450),sx(22),sx(22),p); p.setStyle(Paint.Style.FILL);
        panel(c,100,850,390,1010,Color.rgb(45,35,43));
        centerIn(c,dialogueSpeaker,245,930,24,Color.rgb(230,175,135));
        String raw=dialogueLinesCache.length>0?dialogueLinesCache[dialogueIndex]:"";
        String[] parts=raw.split("\\|",2); String line=parts.length>1?parts[1]:raw;
        drawWrapped(c,line,110,1080,870,32,Color.WHITE);
        center(c,"Нажми, чтобы продолжить",1370,19,Color.GRAY);
    }
    void drawWrapped(Canvas c,String s,float x,float y,float maxWidth,float size,int color){
        p.setTextAlign(Paint.Align.LEFT); p.setTextSize(sx(size)); p.setColor(color);
        String[] words=s.split(" "); String line=""; float yy=sy(y);
        for(String w:words){String test=line.length()==0?w:line+" "+w; if(p.measureText(test)>sx(maxWidth)){c.drawText(line,sx(x),yy,p); yy+=sy(size+10); line=w;}else line=test;}
        if(!line.isEmpty()) c.drawText(line,sx(x),yy,p);
    }
    void loadSave(){
        chapter=save.getInt("chapter",0); coins=save.getInt("coins",0); totalBossesDefeated=save.getInt("bosses",0); deaths=save.getInt("deaths",0);
        weapon=save.getInt("weapon",0); spell=save.getInt("spell",0); weaponLevel=save.getInt("weaponLevel",0); spellLevel=save.getInt("spellLevel",0);
        for(int i=0;i<8;i++) relics[i]=save.getBoolean("relic"+i,false);
    }
    void saveAll(){
        SharedPreferences.Editor e=save.edit(); e.putInt("chapter",chapter).putInt("coins",coins).putInt("bosses",totalBossesDefeated).putInt("deaths",deaths).putInt("weapon",weapon).putInt("spell",spell).putInt("weaponLevel",weaponLevel).putInt("spellLevel",spellLevel);
        for(int i=0;i<8;i++)e.putBoolean("relic"+i,relics[i]); e.apply();
    }
    void newGame(){
        chapter=0; room=0; coins=0; kills=0; deaths=0; totalBossesDefeated=0; weapon=0;spell=0;weaponLevel=0;spellLevel=0;relics=new boolean[8]; saveAll();
        screen=STORY; storyTitle="ПЕПЕЛЬНАЯ КЛЯТВА"; beep(330,100); invalidate();
    }
    void continueGame(){screen=MAP; invalidate();}
    void startChapter(){room=0; screen=MAP; saveAll();}
    void enterRoom(){
        roomType = room>=roomsPerChapter ? 5 : (room==0?0:rng.nextInt(100)<62?0:rng.nextInt(4)+1);
        roomCleared=false; enemies.clear(); projectiles.clear(); loot.clear(); fx.clear(); roomTimer=System.currentTimeMillis(); nextSpawn=0;
        x=W*.5f; y=H*.58f; maxHp=100+25*chapter; hp=maxHp; maxStamina=100; stamina=100; maxEnergy=100; energy=100;
        if(roomType==5){ screen=BOSS; spawnBoss(); }
        else {
            screen=ROOM;
            if(roomType==0)spawnWave(2+chapter);
            else if(roomType==1){ spawnWave(4+chapter*2); for(Enemy e:enemies)e.elite=true; }
            else if(roomType==2){loot.add(new Loot(W*.5f,H*.42f,0));}
            else if(roomType==3){roomCleared=true;}
            else if(roomType==4){screen=SHOP;}
        }
        beep(250+chapter*35,80); invalidate();
    }
    void spawnWave(int count){
        for(int i=0;i<count;i++){Enemy e=new Enemy(); e.kind=(i+chapter)%4; e.x=sx(150)+rng.nextFloat()*(W-sx(300)); e.y=sy(260)+rng.nextFloat()*H*.32f; e.max=34+chapter*8+(e.kind==3?25:0); e.hp=e.max; e.speed=42+chapter*5+e.kind*8; e.attackCd=700+rng.nextInt(700); enemies.add(e);}
    }
    void spawnBoss(){
        Enemy b=new Enemy(); b.boss=true;b.kind=4;b.x=W*.5f;b.y=H*.27f;b.max=520+chapter*170;b.hp=b.max;b.speed=52+chapter*5;b.attackCd=900;enemies.add(b); bossIntro=true; bossPhase=1; bossLowShown=false; startDialogue("boss_pre_"+(chapter+1));
    }

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){W=w;H=h;}
    @Override protected void onDraw(Canvas c){super.onDraw(c); if(W<=0)return; if(screen==MENU)drawMenu(c); else if(screen==STORY)drawStory(c); else if(screen==MAP)drawMap(c); else if(screen==ROOM||screen==BOSS)drawBattle(c); else if(screen==DIALOGUE)drawDialogue(c); else if(screen==REWARD)drawReward(c); else if(screen==SHOP)drawShop(c); else if(screen==PAUSE){drawBattle(c);drawPause(c);} else if(screen==GAMEOVER)drawGameOver(c); else if(screen==VICTORY)drawVictory(c); else if(screen==ARCHIVE)drawArchive(c); else if(screen==EQUIP)drawEquip(c);}

    void bg(Canvas c){
        c.drawColor(Color.rgb(10,8,13)); p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(24,20,28));
        float cell=sx(48); for(float yy=0;yy<H;yy+=cell)for(float xx=0;xx<W;xx+=cell)c.drawRect(xx+1,yy+1,xx+cell-1,yy+cell-1,p);
        p.setColor(Color.argb(24,255,255,255)); for(float yy=0;yy<H;yy+=cell)c.drawRect(0,yy,W,yy+2,p);
        p.setColor(Color.rgb(67,53,59));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sx(5));c.drawRoundRect(sx(24),sy(110),W-sx(24),H-sy(90),sx(24),sx(24),p);p.setStyle(Paint.Style.FILL);
        // torches
        for(int i=0;i<5;i++){float tx=sx(80+i*(W/sx(1)/6f)), ty=sy(150);p.setColor(Color.argb(40,255,160,80));c.drawCircle(tx,ty,sx(32),p);p.setColor(Color.rgb(240,150,75));c.drawCircle(tx,ty,sx(7),p);}
    }
    void title(Canvas c,String s,float y,float size){p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTextSize(sx(size));c.drawText(s,W/2,sy(y),p);}
    void text(Canvas c,String s,float x,float y,float size,int color){p.setTextAlign(Paint.Align.LEFT);p.setColor(color);p.setTextSize(sx(size));c.drawText(s,sx(x),sy(y),p);}
    void center(Canvas c,String s,float y,float size,int color){p.setTextAlign(Paint.Align.CENTER);p.setColor(color);p.setTextSize(sx(size));c.drawText(s,W/2,sy(y),p);}
    void panel(Canvas c,float l,float t,float r,float b,int color){p.setColor(color);c.drawRoundRect(sx(l),sy(t),sx(r),sy(b),sx(18),sx(18),p);}
    void button(Canvas c,float l,float t,float r,float b,String s,boolean active){panel(c,l,t,r,b,active?Color.rgb(105,61,67):Color.rgb(48,40,50));centerIn(c,s,(l+r)/2,(t+b)/2+10,28,Color.WHITE);}
    void centerIn(Canvas c,String s,float x,float y,float size,int color){p.setTextAlign(Paint.Align.CENTER);p.setColor(color);p.setTextSize(sx(size));c.drawText(s,sx(x),sy(y),p);}

    void drawMenu(Canvas c){
        bg(c); title(c,"ASHEN",330,92); center(c,"ОСКОЛКИ ПУСТОТЫ",380,26,Color.rgb(205,91,100));
        if(save.getInt("bosses",0)>0||save.getInt("chapter",0)>0)button(c,190,500,890,600,"ПРОДОЛЖИТЬ",true);
        button(c,190,625,890,725,"НОВАЯ ИГРА",false); button(c,190,750,890,850,"АРХИВ",false);
        center(c,"Ручной бой • один джойстик • без автобоя",930,22,Color.LTGRAY);
        center(c,"Оружие • заклинания • боссы • реликвии • сохранение",965,19,Color.GRAY);
        center(c,"v1.0 — полноценный кампейн-прототип",1030,17,Color.rgb(130,120,135));
    }
    void drawStory(Canvas c){bg(c); title(c,storyTitle,280,48); center(c,"Ты просыпаешься среди пепла. Имя забыто.",390,25,Color.LTGRAY); center(c,"В ладони — клинок, которого ты не помнишь.",430,25,Color.LTGRAY);
        panel(c,120,520,960,1080,Color.rgb(31,26,35));
        center(c,"Голос из-под камня",590,28,Color.rgb(220,170,125));
        center(c,"«Пять хранителей запечатали Пустоту.",660,24,Color.WHITE); center(c,"Но печать держится на чужой памяти.",700,24,Color.WHITE); center(c,"Если вспомнишь себя — мир проснётся.»",740,24,Color.WHITE);
        center(c,"Твоя цель: пройти пять владений и",820,22,Color.LTGRAY); center(c,"решить, что делать с сердцем Пустоты.",855,22,Color.LTGRAY);
        button(c,230,1150,850,1245,"ВОЙТИ В КАТАКОМБЫ",true);
    }
    void drawMap(Canvas c){bg(c); text(c,"ГЛАВА "+(chapter+1)+" / 5",45,70,22,Color.LTGRAY); text(c,chapters[chapter],45,105,30,Color.WHITE); text(c,"ОСКОЛКИ: "+coins,780,70,21,Color.rgb(240,190,110));
        center(c,"ПУТЬ",250,48,Color.rgb(210,170,125));
        float start=380, gap=150; for(int i=0;i<=roomsPerChapter;i++){float yy=start+i*gap; boolean done=i<room; boolean boss=i==roomsPerChapter; p.setColor(done?Color.rgb(100,160,120):(boss?Color.rgb(150,55,70):Color.rgb(95,80,100)));c.drawCircle(W/2,sy(yy),sx(boss?42:31),p); centerIn(c,boss?"Б":""+(i+1),W/(2*S()),yy+10,boss?26:22,Color.WHITE); if(i<roomsPerChapter){p.setColor(Color.rgb(70,55,70));p.setStrokeWidth(sx(8));c.drawLine(W/2,sy(yy+35),W/2,sy(yy+gap-35),p);}}
        panel(c,70,1080,1010,1370,Color.rgb(31,26,35)); text(c,"СНАРЯЖЕНИЕ",105,1130,24,Color.LTGRAY); text(c,"Оружие: "+weaponNames[weapon],105,1175,21,Color.WHITE); text(c,"Заклинание: "+spellNames[spell],105,1215,21,Color.rgb(170,205,255)); text(c,"Выбери свой стиль боя перед комнатой.",105,1260,18,Color.GRAY); button(c,680,1120,950,1200,"АРСЕНАЛ",true);
        button(c,260,1440,820,1535,"ВОЙТИ В СЛЕДУЮЩУЮ КОМНАТУ",true);
    }

    void drawEquip(Canvas c){
        bg(c); title(c,"АРСЕНАЛ",180,52); center(c,"Выбери оружие и заклинание",225,23,Color.LTGRAY);
        text(c,"ОРУЖИЕ",70,300,28,Color.rgb(220,170,125));
        for(int i=0;i<6;i++){int col=i%2,row=i/2;float l=55+col*500,t=330+row*165,r=l+460,b=t+135;panel(c,l,t,r,b,i==weapon?Color.rgb(90,55,62):Color.rgb(35,29,39));text(c,(i+1)+". "+weaponNames[i],l+22,t+48,20,Color.WHITE);text(c,"Урон "+weaponDmg[i]+"  •  дальность "+(int)weaponRange[i],l+22,t+82,16,Color.LTGRAY);if(i==weapon)text(c,"ВЫБРАНО",l+300,t+112,15,Color.rgb(230,180,110));}
        text(c,"ЗАКЛИНАНИЯ",70,885,28,Color.rgb(170,205,255));
        for(int i=0;i<6;i++){int col=i%2,row=i/2;float l=55+col*500,t=915+row*145,r=l+460,b=t+120;panel(c,l,t,r,b,i==spell?Color.rgb(55,55,82):Color.rgb(35,29,39));text(c,(i+1)+". "+spellNames[i],l+22,t+45,19,Color.WHITE);text(c,"Цена "+spellCost[i]+"  •  урон "+spellDmg[i],l+22,t+78,16,Color.LTGRAY);if(i==spell)text(c,"ВЫБРАНО",l+300,t+103,15,Color.rgb(180,205,255));}
        button(c,250,1380,830,1480,"НАЗАД",true);
    }

    void drawBattle(Canvas c){bg(c); drawArenaDecor(c); drawTop(c); for(Projectile q:projectiles)drawProjectile(c,q); for(Enemy e:enemies)drawEnemy(c,e); for(Loot l:loot)drawLoot(c,l); drawPlayer(c); drawFx(c); if(screen==BOSS)drawBossBar(c); drawControls(c); if(roomCleared&&screen==ROOM)drawClearPrompt(c);}
    void drawArenaDecor(Canvas c){
        p.setColor(Color.rgb(43,34,43)); for(int i=0;i<9;i++){float xx=sx(70+i*120), yy=H-sy(270); c.drawRect(xx,yy,xx+sx(80),yy+sy(18),p);} 
        p.setColor(Color.rgb(57,46,52)); c.drawCircle(W*.15f,H*.27f,sx(30),p); c.drawCircle(W*.85f,H*.27f,sx(30),p);
    }
    void drawTop(Canvas c){
        text(c,chapters[chapter],35,52,19,Color.LTGRAY); text(c,"КОМНАТА "+Math.min(room+1,roomsPerChapter+1),35,82,23,Color.WHITE); text(c,"ОСКОЛКИ "+coins,800,52,18,Color.rgb(240,190,110));
        bar(c,35,100,690,124,hp,maxHp,Color.rgb(177,52,65)); bar(c,35,130,470,148,stamina,maxStamina,Color.rgb(70,145,200)); bar(c,35,154,470,172,energy,maxEnergy,Color.rgb(150,90,190));
        if(roomType==3){center(c,"ОТКРОВЕНИЕ",260,40,Color.rgb(220,170,125));center(c,"Здесь никто не ждёт. Только память.",310,24,Color.LTGRAY);}
    }
    void bar(Canvas c,float l,float t,float r,float b,float val,float max,int color){panel(c,l,t,r,b,Color.argb(100,0,0,0));p.setColor(color);c.drawRoundRect(sx(l),sy(t),sx(l+(r-l)*Math.max(0,Math.min(1,val/max))),sy(b),sx(7),sx(7),p);}
    void drawPlayer(Canvas c){
        drawShadow(c,x,y+sy(18)); Bitmap b=System.currentTimeMillis()<attackUntil?heroAttack:(System.currentTimeMillis()<hurtUntil?heroHurt:heroIdle); int frame=(int)((System.currentTimeMillis()/130)%4); drawFrame(c,b,frame,x,y,sx(2.8f));
        if(System.currentTimeMillis()<parryUntil){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sx(5));p.setColor(Color.rgb(210,235,255));c.drawCircle(x,y,sx(48),p);p.setStyle(Paint.Style.FILL);}
        if(System.currentTimeMillis()<dodgeUntil){p.setColor(Color.argb(80,170,220,255));c.drawCircle(x,y,sx(35),p);}
        // aim arrow from same joystick direction
        p.setColor(Color.argb(90,230,220,190));p.setStrokeWidth(sx(3));c.drawLine(x,y,x+dirX*sx(50),y+dirY*sx(50),p);
    }
    void drawEnemy(Canvas c,Enemy e){
        drawShadow(c,e.x,e.y+sy(18)); Bitmap b=e.boss?witch:(e.kind==1?knight:(e.kind==2?witch:knight)); if(e.boss)b=System.currentTimeMillis()<e.attackAnim?witchAttack:witch; else if(e.kind==1)b=System.currentTimeMillis()<e.attackAnim?knightAttack:knight; else if(e.kind==2)b=System.currentTimeMillis()<e.attackAnim?witchAttack:witch;
        float sc=e.boss?sx(4.2f):sx(2.7f); drawFrame(c,b,(int)((System.currentTimeMillis()/170)%4),e.x,e.y,sc); barAt(c,e.x,e.y-sy(e.boss?72:52),e.x-sx(e.boss?85:38),e.x+sx(e.boss?85:38),e.hp,e.max,e.boss?Color.rgb(185,55,75):Color.rgb(125,155,170));
        if(e.elite&&!e.boss){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sx(3));p.setColor(Color.rgb(220,170,90));c.drawCircle(e.x,e.y,sx(34),p);p.setStyle(Paint.Style.FILL);}
    }
    void barAt(Canvas c,float cx,float cy,float l,float r,float val,float max,int color){p.setColor(Color.argb(110,0,0,0));c.drawRoundRect(l,cy,r,cy+sy(8),sx(4),sx(4),p);p.setColor(color);c.drawRoundRect(l,cy,l+(r-l)*Math.max(0,val/max),cy+sy(8),sx(4),sx(4),p);}
    void drawShadow(Canvas c,float xx,float yy){p.setAlpha(100);RectF d=new RectF(xx-sx(26),yy-sy(8),xx+sx(26),yy+sy(8));c.drawBitmap(shadow,null,d,px);p.setAlpha(255);}
    void drawFrame(Canvas c,Bitmap b,int frame,float xx,float yy,float scale){int fw=Math.min(32,b.getWidth()),fh=Math.min(32,b.getHeight());int count=Math.max(1,b.getWidth()/fw);frame=Math.max(0,Math.min(frame,count-1));Rect src=new Rect(frame*fw,0,frame*fw+fw,fh);float ww=fw*scale,hh=fh*scale;c.drawBitmap(b,src,new RectF(xx-ww/2,yy-hh/2,xx+ww/2,yy+hh/2),px);}
    void drawProjectile(Canvas c,Projectile q){p.setColor(q.enemy?Color.rgb(180,75,95):Color.rgb(210,160,90));p.setShadowLayer(sx(12),0,0,q.enemy?Color.MAGENTA:Color.YELLOW);c.drawCircle(q.x,q.y,sx(q.big?12:7),p);p.clearShadowLayer();}
    void drawLoot(Canvas c,Loot l){p.setColor(l.taken?Color.DKGRAY:Color.rgb(205,155,75));p.setShadowLayer(sx(18),0,0,Color.rgb(220,150,80));c.drawCircle(l.x,l.y,sx(26),p);p.clearShadowLayer();centerIn(c,l.type==0?"✦":"?",l.x/S(),l.y/S()+10,25,Color.WHITE);}
    void drawFx(Canvas c){for(Fx f:fx){float a=1f-(System.currentTimeMillis()-f.birth)/(float)f.life;p.setColor(Color.argb((int)(Math.max(0,a)*180),f.colorR,f.colorG,f.colorB));c.drawCircle(f.x,f.y,sx(f.size*(1+(1-a))),p);}}
    void drawControls(Canvas c){
        float baseX=sx(145),baseY=H-sy(165);p.setColor(Color.argb(45,255,255,255));c.drawCircle(baseX,baseY,sx(105),p);p.setColor(Color.argb(80,255,255,255));float knobX=moveTouch?joyX:baseX,knobY=moveTouch?joyY:baseY;c.drawCircle(knobX,knobY,sx(36),p);
        action(c,W-sx(125),H-sy(175),sx(56),"⚔",0); action(c,W-sx(70),H-sy(290),sx(52),"↯",1); action(c,W-sx(205),H-sy(290),sx(52),"✦",2); action(c,W-sx(205),H-sy(150),sx(52),"◈",3); if(screen!=BOSS) action(c,W-sx(315),H-sy(225),sx(46),"i",4);
        centerIn(c,weaponNames[weapon],W/S()-190,170,17,Color.LTGRAY); centerIn(c,spellNames[spell],W/S()-180,195,15,Color.rgb(180,205,255));
    }
    void action(Canvas c,float xx,float yy,float rr,String s,int i){p.setColor(pressed[i]?Color.argb(150,190,150,155):Color.argb(55,255,255,255));c.drawCircle(xx,yy,rr,p);centerIn(c,s,xx/S(),yy/S()+10,30,Color.WHITE);}
    void drawClearPrompt(Canvas c){panel(c,210,700,870,920,Color.argb(225,20,16,25));center(c,"КОМНАТА ОЧИЩЕНА",770,30,Color.WHITE);center(c,"Нажми i для продолжения",820,21,Color.LTGRAY);}
    void drawBossBar(Canvas c){if(enemies.size()==0)return;Enemy b=enemies.get(0);panel(c,170,190,910,245,Color.argb(180,15,12,18));center(c,bossNames[chapter],225,22,Color.WHITE);bar(c,195,205,885,225,b.hp,b.max,Color.rgb(190,55,75)); center(c,"ФАЗА "+bossPhase,260,18,Color.GRAY);}

    void drawReward(Canvas c){bg(c);title(c,"НАГРАДА",260,52);center(c,"Выбери одно усиление",320,24,Color.LTGRAY);String[] opts={"+25 МАКС. HP","+20 МАКС. ЭНЕРГИИ","+12 УРОН ОРУЖИЯ"};for(int i=0;i<3;i++){float y=470+i*230;panel(c,120,y,960,y+160,Color.rgb(35,29,39));centerIn(c,(i+1)+"",180,y+65,38,Color.rgb(220,170,125));text(c,opts[i],250,y+70,27,Color.WHITE);text(c,i==0?"Здоровье":"Сила билда",250,y+108,18,Color.LTGRAY);}center(c,"Нажми на одну из карт",1210,21,Color.GRAY);}
    void drawShop(Canvas c){bg(c);title(c,"ЛАВКА ПЕПЕЛЬЩИКА",240,48);center(c,"Осколки: "+coins,300,24,Color.rgb(240,190,110));String[] a={"Улучшить оружие","Улучшить заклинание","Купить реликвию","Выйти"};for(int i=0;i<4;i++)button(c,150,430+i*170,930,545+i*170,a[i],i==0);center(c,"Каждая покупка сохраняется",1170,20,Color.GRAY);}
    void drawPause(Canvas c){panel(c,120,420,960,1110,Color.argb(235,12,10,16));title(c,"ПАУЗА",570,52);button(c,220,680,860,770,"ПРОДОЛЖИТЬ",true);button(c,220,800,860,890,"СОХРАНИТЬ",false);button(c,220,920,860,1010,"В МЕНЮ",false);}
    void drawGameOver(Canvas c){bg(c);title(c,"ПЕПЕЛ ПОГЛОТИЛ ТЕБЯ",430,50);center(c,"Смерть не отменяет найденные реликвии.",510,23,Color.LTGRAY);center(c,"Попробуй снова — Пустота помнит твои попытки.",550,21,Color.GRAY);button(c,200,720,880,820,"ВОЗРОДИТЬСЯ",true);button(c,200,850,880,950,"В МЕНЮ",false);}
    void drawVictory(Canvas c){bg(c);title(c,"ПУСТОТА ОТКРЫТА",330,56);center(c,"Астер пал. Но дверь не закрылась.",430,26,Color.LTGRAY);center(c,"Теперь ты можешь выбрать судьбу Пепла.",475,24,Color.WHITE);panel(c,110,590,970,1120,Color.rgb(31,26,35));center(c,"ИСТИННАЯ КОНЦОВКА",660,30,Color.rgb(220,170,125));center(c,"Ты вспоминаешь своё имя.",740,24,Color.WHITE);center(c,"Ты был первым, кто запечатал Пустоту.",780,23,Color.LTGRAY);center(c,"И последним, кто способен решить её судьбу.",820,23,Color.LTGRAY);button(c,240,930,840,1020,"НАЧАТЬ НОВЫЙ ЦИКЛ",true);}
    void drawArchive(Canvas c){bg(c);title(c,"АРХИВ ПАМЯТИ",220,50);text(c,"ОТКРЫТО БОССОВ: "+totalBossesDefeated+" / 5",100,340,25,Color.WHITE);for(int i=0;i<5;i++){boolean open=i<totalBossesDefeated;panel(c,100,390+i*150,980,510+i*150,open?Color.rgb(44,35,43):Color.rgb(25,22,29));text(c,(i+1)+". "+bossNames[i],130,445+i*150,22,open?Color.WHITE:Color.GRAY);text(c,open?bossLore[i]:"Запись скрыта",130,480+i*150,16,open?Color.LTGRAY:Color.DKGRAY);}button(c,260,1180,820,1270,"НАЗАД",true);}

    @Override public boolean onTouchEvent(MotionEvent e){
        int a=e.getActionMasked();
        int idx=e.getActionIndex();
        int id=e.getPointerId(idx);
        float tx=e.getX(idx), ty=e.getY(idx);

        if(a==MotionEvent.ACTION_DOWN){
            if(screen==DIALOGUE){ nextDialogue(); return true; }
            if(screen==MENU){
                if(ty>sy(470)&&ty<sy(620)&&save.getInt("chapter",0)>0){continueGame();return true;}
                if(ty>sy(610)&&ty<sy(760)){newGame();return true;}
                if(ty>sy(740)&&ty<sy(880)){screen=ARCHIVE;invalidate();return true;}
            } else if(screen==STORY){
                if(ty>sy(1080)){startChapter();return true;}
            } else if(screen==MAP){
                if(tx>sx(620)&&tx<sx(1000)&&ty>sy(1090)&&ty<sy(1230)){screen=EQUIP;invalidate();return true;}
                if(ty>sy(1360)){enterRoom();return true;}
            } else if(screen==EQUIP){
                if(ty>sy(320)&&ty<sy(800)){int col=tx>W/2?1:0;int row=(int)((ty-sy(330))/sy(165));int i=row*2+col;if(i>=0&&i<6){weapon=i;saveAll();invalidate();}return true;}
                if(ty>sy(900)&&ty<sy(1350)){int col=tx>W/2?1:0;int row=(int)((ty-sy(915))/sy(145));int i=row*2+col;if(i>=0&&i<6){spell=i;saveAll();invalidate();}return true;}
                if(ty>sy(1360)){screen=MAP;invalidate();return true;}
            } else if(screen==ROOM||screen==BOSS){
                if(tx>W-sx(100) && ty<sy(110)){screen=PAUSE;saveAll();invalidate();return true;}
                if(screen==BOSS&&bossIntro){bossIntro=false;invalidate();return true;}
                if(tx<W*.48f && ty>H-sy(330)){
                    moveTouch=true; moveId=id; joyX=tx; joyY=ty; updateDirection(tx,ty); return true;
                }
                int b=buttonAt(tx,ty);
                if(b>=0){
                    pressed[b]=true; buttonPointerId[b]=id;
                    if(b==4) advanceRoom(); else trigger(b);
                    invalidate(); return true;
                }
                if(screen==BOSS&&bossIntro){bossIntro=false;invalidate();return true;}
            } else if(screen==REWARD){chooseReward((int)((ty-sy(430))/sy(230)));return true;}
            else if(screen==SHOP){int row=(int)((ty-sy(400))/sy(170));buy(row);return true;}
            else if(screen==PAUSE){
                if(ty>sy(650)&&ty<sy(790)){screen=ROOM;invalidate();return true;}
                if(ty>sy(790)&&ty<sy(910)){saveAll();beep(650,60);return true;}
                if(ty>sy(900)&&ty<sy(1040)){saveAll();screen=MENU;invalidate();return true;}
            } else if(screen==GAMEOVER){
                if(ty>sy(690)&&ty<sy(850)){enterRoom();screen=ROOM;return true;}
                if(ty>sy(830)&&ty<sy(990)){screen=MENU;invalidate();return true;}
            } else if(screen==VICTORY){if(ty>sy(900)){newGame();return true;}}
            else if(screen==ARCHIVE){if(ty>sy(1130)){screen=MENU;invalidate();return true;}}
        } else if(a==MotionEvent.ACTION_POINTER_DOWN){
            // A second finger is ONLY allowed to press an action button.
            // It must never create or steal the movement joystick.
            if(screen==ROOM||screen==BOSS){
                int b=buttonAt(tx,ty);
                if(b>=0){
                    pressed[b]=true; buttonPointerId[b]=id;
                    if(b==4) advanceRoom(); else trigger(b);
                    invalidate(); return true;
                }
            }
        } else if(a==MotionEvent.ACTION_MOVE){
            if(moveTouch){
                int j=e.findPointerIndex(moveId);
                if(j>=0){
                    joyX=e.getX(j); joyY=e.getY(j); updateDirection(joyX,joyY);
                }
            }
        } else if(a==MotionEvent.ACTION_POINTER_UP){
            if(id==moveId){
                // Keep the joystick alive if another finger is still holding it.
                moveTouch=false; moveId=-1;
                for(int i=0;i<e.getPointerCount();i++){
                    int otherId=e.getPointerId(i);
                    if(otherId==id) continue;
                    float ox=e.getX(i), oy=e.getY(i);
                    if(ox<W*.48f && oy>H-sy(330)){
                        moveTouch=true; moveId=otherId; joyX=ox; joyY=oy; updateDirection(ox,oy); break;
                    }
                }
            }
            for(int b=0;b<pressed.length;b++){
                if(buttonPointerId[b]==id){pressed[b]=false;buttonPointerId[b]=-1;}
            }
            invalidate();
        } else if(a==MotionEvent.ACTION_UP || a==MotionEvent.ACTION_CANCEL){
            if(a==MotionEvent.ACTION_UP && id==moveId){moveTouch=false;moveId=-1;}
            if(a==MotionEvent.ACTION_CANCEL){moveTouch=false;moveId=-1;}
            for(int b=0;b<pressed.length;b++){
                if(a==MotionEvent.ACTION_CANCEL || buttonPointerId[b]==id){pressed[b]=false;buttonPointerId[b]=-1;}
            }
            invalidate();
        }
        return true;
    }
    void updateDirection(float tx,float ty){float bx=sx(145),by=H-sy(165);float dx=tx-bx,dy=ty-by;float n=(float)Math.hypot(dx,dy);if(n>sx(16)){dirX=dx/n;dirY=dy/n;}}
    int buttonAt(float tx,float ty){float[][] q={{W-sx(125),H-sy(175)},{W-sx(70),H-sy(290)},{W-sx(205),H-sy(290)},{W-sx(205),H-sy(150)},{W-sx(315),H-sy(225)}};float[] r={56,52,52,52,46};int count=screen==BOSS?4:5;for(int i=0;i<count;i++)if(Math.hypot(tx-q[i][0],ty-q[i][1])<sx(r[i]+8))return i;return -1;}

    void trigger(int b){if(screen!=ROOM&&screen!=BOSS)return;long now=System.currentTimeMillis();if(b==0)attack();else if(b==1)dodge();else if(b==2)castSpell();else if(b==3)parry();}
    void attack(){long now=System.currentTimeMillis();if(now<attackUntil)return;float cd=weaponCd[weapon]-weaponLevel*12;attackUntil=now+(long)Math.max(130,cd);combo=(now<comboUntil)?(combo%3)+1:1;comboUntil=now+700;int dmg=weaponDmg[weapon]+weaponLevel*8+(combo==3?12:0);float range=sx(weaponRange[weapon]+weaponLevel*4);for(Enemy e:new ArrayList<>(enemies)){float dx=e.x-x,dy=e.y-y,d=(float)Math.hypot(dx,dy);if(d<range){float dot=(dx*dirX+dy*dirY)/(d+.01f);if(dot>0.15f){hitEnemy(e,dmg);}}}fx.add(new Fx(x+dirX*sx(45),y+dirY*sx(45),System.currentTimeMillis(),80,36,245,190,120));beep(190+combo*45,45);}
    void hitEnemy(Enemy e,float dmg){e.hp-=dmg;e.attackAnim=System.currentTimeMillis()+180;fx.add(new Fx(e.x,e.y,System.currentTimeMillis(),120,26,220,90,90));if(e.hp<=0){
            coins+=e.boss?90:8+chapter*2; kills++;
            if(e.boss){
                totalBossesDefeated++; bossDeathPending=true; saveAll();
                startDialogue("boss_death_"+(chapter+1)); beep(80,400);
            }else{ enemies.remove(e); if(enemies.isEmpty())roomCleared=true; }
        }
        else if(e.boss && bossPhase==1 && e.hp<=e.max*0.5f){
            bossPhase=2; startDialogue("boss_phase2_"+(chapter+1));
        }
        else if(e.boss && bossPhase==2 && e.hp<=e.max*0.2f && !bossLowShown){
            bossLowShown=true; startDialogue("boss_low_"+(chapter+1));
        }
    }
    void dodge(){long now=System.currentTimeMillis();if(now<dodgeUntil||stamina<24)return;stamina-=24;dodgeUntil=now+280;invulnUntil=now+360;x+=dirX*sx(105);y+=dirY*sy(105);clampPlayer();fx.add(new Fx(x,y,now,180,24,150,210,255));beep(650,50);}
    void castSpell(){long now=System.currentTimeMillis();int cost=spellCost[spell];if(now<spellUntil||energy<cost)return;energy-=cost;long cd=500-Math.min(180,spellLevel*25);spellUntil=now+cd;
        if(spell==5){hp=Math.min(maxHp,hp+32+spellLevel*8);fx.add(new Fx(x,y,now,350,55,170,130,230));beep(780,90);return;}
        if(spell==4){for(int i=1;i<=3;i++){Projectile q=new Projectile(x+dirX*sx(40),y+dirY*sy(40),dirX*500,dirY*500,false,true,spellDmg[spell]+spellLevel*15);q.delay=i*120;projectiles.add(q);}beep(950,110);return;}
        Projectile q=new Projectile(x+dirX*sx(35),y+dirY*sy(35),dirX*470,dirY*470,false,spell==3,spellDmg[spell]+spellLevel*8);q.big=spell==3;projectiles.add(q);beep(720+spell*55,85);
    }
    void parry(){long now=System.currentTimeMillis();if(now<parryUntil||stamina<14)return;stamina-=14;parryUntil=now+240;beep(1150,50);}
    void advanceRoom(){if(screen==BOSS){if(enemies.isEmpty()){chapter++;room=0;saveAll();screen=chapter>=5?VICTORY:MAP;}return;}if(!roomCleared&&roomType!=2&&roomType!=3)return;if(roomType==2&&!loot.isEmpty()&&!loot.get(0).taken){loot.get(0).taken=true;coins+=30+chapter*10;beep(620,80);return;}room++;saveAll();if(room>roomsPerChapter){screen=BOSS;enemies.clear();spawnBoss();}else{screen=MAP;}invalidate();}
    void chooseReward(int idx){if(idx<0||idx>2)return;if(idx==0){maxHp+=25;hp=maxHp;}else if(idx==1){maxEnergy+=20;energy=maxEnergy;}else{weaponLevel++;}saveAll();room=0;screen=MAP;beep(500+idx*120,80);invalidate();}
    void buy(int row){if(row<0||row>3)return;if(row==0&&coins>=40){coins-=40;weaponLevel++;}else if(row==1&&coins>=45){coins-=45;spellLevel++;}else if(row==2&&coins>=70){coins-=70;for(int i=0;i<relics.length;i++)if(!relics[i]){relics[i]=true;break;}}else if(row==3){room++;saveAll();screen=MAP;}saveAll();invalidate();}

    void update(){long now=System.currentTimeMillis();float dt=Math.min(.04f,(System.nanoTime()-last)/1e9f);last=System.nanoTime();
        if(screen==ROOM||screen==BOSS){
            if(moveTouch){float bx=sx(145),by=H-sy(165),dx=joyX-bx,dy=joyY-by,n=(float)Math.hypot(dx,dy);if(n>sx(12)){float m=Math.min(1,n/sx(105));x+=dx/n*220*m*dt;y+=dy/n*220*m*dt;updateDirection(joyX,joyY);}}
            clampPlayer(); stamina=Math.min(maxStamina,stamina+32*dt); energy=Math.min(maxEnergy,energy+10*dt);
            for(Projectile q:new ArrayList<>(projectiles)){if(now<q.delay+q.birth)continue;q.x+=q.vx*dt;q.y+=q.vy*dt;q.life-=dt;if(q.life<=0||q.x<0||q.x>W||q.y<sy(100)||q.y>H-sy(260)){projectiles.remove(q);continue;}if(!q.enemy){for(Enemy e:new ArrayList<>(enemies)){if(Math.hypot(q.x-e.x,q.y-e.y)<sx(q.big?55:34)){hitEnemy(e,q.damage);projectiles.remove(q);break;}}}else if(Math.hypot(q.x-x,q.y-y)<sx(28)){if(now>invulnUntil)takeDamage(q.damage);projectiles.remove(q);}}
            for(Enemy e:new ArrayList<>(enemies))updateEnemy(e,dt,now);
            if(screen==BOSS&&enemies.isEmpty()){bossIntro=false;roomCleared=true;}
            if(roomType==0&&roomCleared){/* wait */}
        }
        for(Fx f:new ArrayList<>(fx))if(now-f.birth>f.life)fx.remove(f);
        invalidate();
    }
    void updateEnemy(Enemy e,float dt,long now){
        if(e.boss){float phase=e.hp/e.max; if(phase<.5f)e.speed=75+chapter*5;}
        float dx=x-e.x,dy=y-e.y,d=(float)Math.hypot(dx,dy); if(d>sx(e.boss?125:58)){e.x+=dx/d*e.speed*dt;e.y+=dy/d*e.speed*dt;}
        if(now>e.attackCd){e.attackCd=now+(e.boss?700:1100-e.kind*80);e.attackAnim=now+250;if(e.boss){bossAttack(e);}else if(e.kind==2){Projectile q=new Projectile(e.x,e.y,dx/(d+.01f)*280,dy/(d+.01f)*280,true,false,10+chapter*3);q.big=true;projectiles.add(q);beep(260,30);}else if(d<100){if(now>invulnUntil)takeDamage(8+chapter*2+e.kind*2);else {e.hp-=12;fx.add(new Fx(e.x,e.y,now,120,20,210,230,255));}}}
    }
    void bossAttack(Enemy b){int pattern=(int)(System.currentTimeMillis()/700)%4;float dx=x-b.x,dy=y-b.y,d=(float)Math.hypot(dx,dy);if(pattern==0){for(int i=0;i<8;i++){double a=i*Math.PI/4;projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*220,(float)Math.sin(a)*220,true,false,14+chapter*4));}}else if(pattern==1){projectiles.add(new Projectile(b.x,b.y,dx/(d+.01f)*420,dy/(d+.01f)*420,true,true,22+chapter*4));}else if(pattern==2){b.x=W*.2f+rng.nextFloat()*W*.6f;b.y=sy(250)+rng.nextFloat()*H*.22f;for(int i=0;i<3;i++)projectiles.add(new Projectile(b.x,b.y,dirX*260+(rng.nextFloat()-.5f)*100,dirY*260+(rng.nextFloat()-.5f)*100,true,false,18));}else{fx.add(new Fx(x,y,System.currentTimeMillis(),300,80,190,55,70));if(System.currentTimeMillis()>invulnUntil&&Math.hypot(x-b.x,y-b.y)<sx(250))takeDamage(24+chapter*5);}beep(110,70);}
    void takeDamage(float dmg){long now=System.currentTimeMillis();if(now<invulnUntil)return;hp-=dmg;hurtUntil=now+240;flash=now+100;fx.add(new Fx(x,y,now,180,30,220,70,80));beep(95,45);if(hp<=0){deaths++;saveAll();screen=GAMEOVER;}}
    void clampPlayer(){x=Math.max(sx(55),Math.min(W-sx(55),x));y=Math.max(sy(190),Math.min(H-sy(300),y));}
    void beep(int f,int d){try{if(tone!=null)tone.startTone(ToneGenerator.TONE_PROP_BEEP2,Math.min(d,300));}catch(Exception ignored){}}

    Runnable tick=new Runnable(){public void run(){update();postDelayed(this,16);}};

    static class Enemy{float x,y,hp,max,speed;int kind;boolean boss,elite;long attackCd,attackAnim;}
    static class Projectile{float x,y,vx,vy,damage,life=4f;boolean enemy,big;long birth=System.currentTimeMillis(),delay=0;Projectile(float X,float Y,float Vx,float Vy,boolean E,boolean B,float D){x=X;y=Y;vx=Vx;vy=Vy;enemy=E;big=B;damage=D;}}
    static class Fx{float x,y,size;long birth,life;int colorR,colorG,colorB;Fx(float X,float Y,long B,long L,float S,int R,int G,int Bl){x=X;y=Y;birth=B;life=L;size=S;colorR=R;colorG=G;colorB=Bl;}}
    static class Loot{float x,y;int type;boolean taken;Loot(float X,float Y,int T){x=X;y=Y;type=T;}}
}
