ASHEN — сборка APK через GitHub (только с телефона)

Тебе НЕ нужно открывать Android Studio.

В этом наборе:
1) ASHEN_ANDROID_PROJECT.zip — исходный Android-проект.
2) BUILD_WORKFLOW.yml.txt — текст GitHub Actions workflow.
3) README_FIRST_RU.txt — инструкция.

На GitHub нужно загрузить ASHEN_ANDROID_PROJECT.zip. Затем создать файл .github/workflows/build.yml и вставить содержимое BUILD_WORKFLOW.yml.txt.
После этого открыть Actions → Build ASHEN APK → Run workflow.
Готовый APK появится в результате запуска как Artifact с названием ASHEN-debug-apk.
