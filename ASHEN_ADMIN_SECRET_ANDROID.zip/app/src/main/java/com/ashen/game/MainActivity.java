package com.ashen.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;
import java.io.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        setContentView(new GameView(this));
    }
}

class GameView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint px = new Paint();
    final Random rng = new Random();
    final SharedPreferences save;
    ToneGenerator tone;

    Bitmap heroIdle, heroAttack, heroHurt, heroDeath, knight, knightAttack, witch, witchAttack, fireball, shadow, blood, arrow;
    float W,H,ui;
    long last;

    // Screens
    static final int MENU=0, STORY=1, MAP=2, ROOM=3, REWARD=4, SHOP=5, BOSS=6, PAUSE=7, GAMEOVER=8, VICTORY=9, ARCHIVE=10, EQUIP=11, DIALOGUE=12, ADMIN=13, SECRET=14;
    int screen=MENU;

    // Campaign
    int chapter=0, room=0, roomsPerChapter=4, totalBossesDefeated=0;
    int coins=0, kills=0, deaths=0;
    String storyTitle="";
    boolean bossIntro=false;
    boolean bossDeathPending=false;
    boolean bossLowShown=false;
    int bossPhase=1;
    ArrayList<String> dialogueLines=new ArrayList<>();
    int dialogueIndex=0;
    String dialogueSpeaker="";
    String dialogueMoment="";

    // Hidden admin / secret ending
    boolean adminUnlocked=false;
    boolean adminSpellBurst=false;
    boolean adminHealth=false;
    boolean adminFreeWorld=false;
    int adminTapCount=0;
    long adminTapWindow=0;
    long secretStart=0;
    float secretHeartScale=0;
    boolean secretHalf=false;

    // Player
    float x,y,hp,maxHp,stamina,maxStamina,energy,maxEnergy;
    float dirX=0,dirY=1;
    boolean moveTouch=false; int moveId=-1; float joyX,joyY;
    long attackUntil=0,spellUntil=0,dodgeUntil=0,parryUntil=0,invulnUntil=0,hurtUntil=0,shieldUntil=0,weaponBuffUntil=0;
    int combo=0; long comboUntil=0;
    int weapon=0, spell=0;
    boolean[] relics=new boolean[8];
    int weaponLevel=0, spellLevel=0;

    // Room
    int roomType=0; // 0 combat, 1 elite, 2 treasure, 3 lore, 4 shop, 5 boss
    boolean roomCleared=false;
    ArrayList<Enemy> enemies=new ArrayList<>();
    ArrayList<Projectile> projectiles=new ArrayList<>();
    ArrayList<Fx> fx=new ArrayList<>();
    ArrayList<Loot> loot=new ArrayList<>();
    long roomTimer=0, nextSpawn=0, flash=0;

    // Touch action buttons: attack,dodge,spell,parry,interact
    boolean[] pressed=new boolean[5];
    int[] buttonPointerId={-1,-1,-1,-1,-1};

    final String[] chapters={"ПЕПЕЛЬНЫЕ КАТАКОМБЫ","ЗАТОПЛЕННАЯ ЧАСОВНЯ","ЧЁРНАЯ КУЗНИЦА","САД БЕЗ СВЕТА","ТРОН ПУСТОТЫ"};
    final String[] bossNames={"КАЭЛЬ, ПОСЛЕДНИЙ СТРАЖ","МАТЬ УГЛЕЙ","ВАРГАН, ЖЕЛЕЗНЫЙ ПАЛАЧ","ИЛЬРА, САДОВНИЦА ТИШИНЫ","АСТЕР, ПЕРВЫЙ ПЕПЕЛ"};
    final String[] bossLore={
            "Когда-то Каэль охранял дверь к Пустоте. Он забыл, кого защищал.",
            "Мать Углей питается воспоминаниями погибших и не умеет отпускать мёртвых.",
            "Варган ковал цепи для тех, кто пытался бежать из мира Пепла.",
            "Ильра превратила души во цветы, чтобы остановить течение времени.",
            "Астер — тот, кто первым услышал голос Пустоты. Он зовёт героя по имени."
    };

    final String[] weaponNames={"ПЕПЕЛЬНЫЙ КЛИНОК","КОПЬЁ ЗВОНА","КОСА МОЛЧАНИЯ","ПАРНЫЕ КЛИНКИ","МОЛОТ КОВАЛЯ","ЦЕПНОЙ КЛИНОК","ЛУК ПЕПЛА","КЛИНОК ПУСТОТЫ","ПАЛАЧ ПЕПЛА","КИНЖАЛ ТЕНЕЙ","КЛИНОК РАСКОЛА","ЖЕЗЛ ПЕРВОГО ОГНЯ"};
    final int[] weaponDmg={34,30,43,22,62,36,28,39,70,25,48,26};
    final float[] weaponRange={94,138,118,86,112,145,420,104,125,90,105,360};
    final float[] weaponCd={270,360,430,150,560,300,260,280,650,135,330,300};
    final int[] weaponUnlock={0,0,1,1,2,2,2,3,3,3,4,4};
    final String[] weaponDesc={"Комбо и парирование","Дальний выпад","Широкая дуга","Очень быстрые удары","Тяжёлый удар и оглушение","Длинная цепь","Дальний выстрел","Лечит за добивания","Огромный урон, медленно","Высокий шанс крит. удара","Пробивает броню","Энергетический луч"};
    final String[] spellNames={"ОГНЕННЫЙ ШАР","ЛЕДЯНОЙ ОСКОЛОК","ЦЕПЬ ТЕНИ","ГРОМОВОЙ ИМПУЛЬС","МЕТЕОР","ПЕПЕЛЬНОЕ СЕРДЦЕ","ОГНЕННАЯ ВОЛНА","МОРОЗНАЯ КЛЕТКА","ЦЕПНАЯ МОЛНИЯ","ГРОЗОВОЙ ЗНАК","ТЕНЕВОЙ РЫВОК","ЧЁРНАЯ ДЫРА","КРОВАВАЯ МЕТКА","ЖЕРТВОПРИНОШЕНИЕ","ОСКОЛОЧНЫЙ ЩИТ","ЯДОВИТЫЙ ТУМАН","ГРАВИТАЦИОННЫЙ РАЗЛОМ","ФЕНИКС"};
    final int[] spellCost={24,28,32,38,50,42,34,40,44,46,30,58,36,45,40,38,52,70};
    final int[] spellDmg={44,54,36,72,120,0,52,26,78,64,20,18,42,80,0,30,68,130};
    final int[] spellUnlock={0,0,0,0,0,0,1,1,1,1,2,2,3,3,3,4,4,4};
    final String[] spellDesc={"Быстрый снаряд","Замедляет врага","Три теневых клинка","Удар по площади","Три падающих взрыва","Восстанавливает HP","Широкий огненный конус","Замораживает цель","Молния перескакивает","Ловушка на земле","Рывок сквозь врагов","Стягивает врагов","Усиляет урон по цели","Жертва ради силы","Щит","Ядовитая зона","Тянет врагов","Большой взрыв"};

    GameView(Context c){
        super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); px.setFilterBitmap(false);
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));
        heroIdle=load(c,R.drawable.hero_idle); heroAttack=load(c,R.drawable.hero_attack); heroHurt=load(c,R.drawable.hero_hurt); heroDeath=load(c,R.drawable.hero_death);
        knight=load(c,R.drawable.enemy_knight); knightAttack=load(c,R.drawable.enemy_knight_attack); witch=load(c,R.drawable.enemy_witch); witchAttack=load(c,R.drawable.enemy_witch_attack);
        fireball=load(c,R.drawable.fireball); shadow=load(c,R.drawable.shadow); blood=load(c,R.drawable.blood); arrow=load(c,R.drawable.arrow);
        save=c.getSharedPreferences("ashen_full",Context.MODE_PRIVATE);
        loadDialogue();
        loadSave();
        try{tone=new ToneGenerator(AudioManager.STREAM_MUSIC,55);}catch(Exception ignored){}
        last=System.nanoTime(); post(tick);
    }
    Bitmap load(Context c,int id){return BitmapFactory.decodeResource(c.getResources(),id);}
    float S(){return Math.min(W/1080f,H/1920f);}
    float sx(float v){return v*S();}
    float sy(float v){return v*S();}
    void loadDialogue(){
        try{
            InputStream in=getContext().getAssets().open("story_ru.txt");
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            String line;
            while((line=br.readLine())!=null) dialogueLines.add(line);
            br.close();
        }catch(Exception e){
            dialogueLines.clear();
        }
    }
    String[] getDialogue(String key){
        ArrayList<String> out=new ArrayList<>();
        String prefix=key+"|";
        for(String line:dialogueLines) if(line.startsWith(prefix)) out.add(line.substring(prefix.length()));
        return out.toArray(new String[0]);
    }
    void startDialogue(String key){
        String[] lines=getDialogue(key);
        if(lines.length==0)return;
        dialogueLinesCache=lines; dialogueIndex=0; dialogueMoment=key;
        String[] first=lines[0].split("\\|",2);
        dialogueSpeaker=first.length>1?first[0]:"";
        screen=DIALOGUE;
        saveAll(); invalidate();
    }
    String[] dialogueLinesCache=new String[0];
    void nextDialogue(){
        dialogueIndex++;
        if(dialogueIndex>=dialogueLinesCache.length){
            finishDialogue(); return;
        }
        String[] parts=dialogueLinesCache[dialogueIndex].split("\\|",2);
        dialogueSpeaker=parts.length>1?parts[0]:"";
        invalidate();
    }
    void finishDialogue(){
        String key=dialogueMoment;
        dialogueLinesCache=new String[0]; dialogueIndex=0; dialogueSpeaker=""; dialogueMoment="";
        if(key.startsWith("boss_pre_")){ screen=BOSS; bossIntro=false; return; }
        if(key.startsWith("boss_phase2_")){ screen=BOSS; bossPhase=2; return; }
        if(key.startsWith("boss_low_")){ screen=BOSS; return; }
        if(key.startsWith("boss_death_")){
            bossDeathPending=false;
            if(chapter>=4){ screen=VICTORY; } else { chapter++; room=0; screen=REWARD; }
            saveAll(); return;
        }
        screen=BOSS;
    }
    void drawDialogue(Canvas c){
        bg(c);
        drawArenaDecor(c);
        for(Enemy e:enemies) drawEnemy(c,e);
        drawPlayer(c);
        panel(c,70,820,1010,1450,Color.argb(238,12,10,17));
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sx(3)); p.setColor(Color.rgb(130,100,110));
        c.drawRoundRect(sx(70),sy(820),sx(1010),sy(1450),sx(22),sx(22),p); p.setStyle(Paint.Style.FILL);
        panel(c,100,850,390,1010,Color.rgb(45,35,43));
        centerIn(c,dialogueSpeaker,245,930,24,Color.rgb(230,175,135));
        String raw=dialogueLinesCache.length>0?dialogueLinesCache[dialogueIndex]:"";
        String[] parts=raw.split("\\|",2); String line=parts.length>1?parts[1]:raw;
        drawWrapped(c,line,110,1080,870,32,Color.WHITE);
        center(c,"Нажми, чтобы продолжить",1370,19,Color.GRAY);
    }
    void drawWrapped(Canvas c,String s,float x,float y,float maxWidth,float size,int color){
        p.setTextAlign(Paint.Align.LEFT); p.setTextSize(sx(size)); p.setColor(color);
        String[] words=s.split(" "); String line=""; float yy=sy(y);
        for(String w:words){String test=line.length()==0?w:line+" "+w; if(p.measureText(test)>sx(maxWidth)){c.drawText(line,sx(x),yy,p); yy+=sy(size+10); line=w;}else line=test;}
        if(!line.isEmpty()) c.drawText(line,sx(x),yy,p);
    }
    void loadSave(){
        chapter=save.getInt("chapter",0); coins=save.getInt("coins",0); totalBossesDefeated=save.getInt("bosses",0); deaths=save.getInt("deaths",0);
        weapon=save.getInt("weapon",0); spell=save.getInt("spell",0); weaponLevel=save.getInt("weaponLevel",0); spellLevel=save.getInt("spellLevel",0);
        for(int i=0;i<8;i++) relics[i]=save.getBoolean("relic"+i,false);
        adminUnlocked=save.getBoolean("adminUnlocked",false);
        adminSpellBurst=save.getBoolean("adminSpellBurst",false);
        adminHealth=save.getBoolean("adminHealth",false);
        adminFreeWorld=save.getBoolean("adminFreeWorld",false);
    }
    void saveAll(){
        SharedPreferences.Editor e=save.edit(); e.putInt("chapter",chapter).putInt("coins",coins).putInt("bosses",totalBossesDefeated).putInt("deaths",deaths).putInt("weapon",weapon).putInt("spell",spell).putInt("weaponLevel",weaponLevel).putInt("spellLevel",spellLevel);
        for(int i=0;i<8;i++)e.putBoolean("relic"+i,relics[i]);
        e.putBoolean("adminUnlocked",adminUnlocked).putBoolean("adminSpellBurst",adminSpellBurst)
         .putBoolean("adminHealth",adminHealth).putBoolean("adminFreeWorld",adminFreeWorld);
        e.apply();
    }
    void newGame(){
        chapter=0; room=0; coins=0; kills=0; deaths=0; totalBossesDefeated=0; weapon=0;spell=0;weaponLevel=0;spellLevel=0;relics=new boolean[8]; saveAll();
        screen=STORY; storyTitle="ПЕПЕЛЬНАЯ КЛЯТВА"; beep(330,100); invalidate();
    }
    void continueGame(){screen=MAP; invalidate();}
    void startChapter(){room=0; screen=MAP; saveAll();}
    void enterRoom(){
        if(room>=roomsPerChapter) roomType=5;
        else if(room==0) roomType=0;
        else { int roll=rng.nextInt(100); if(roll<7) roomType=3; else if(roll<19) roomType=4; else if(roll<34) roomType=2; else if(roll<52) roomType=1; else roomType=0; }
        roomCleared=false; enemies.clear(); projectiles.clear(); loot.clear(); fx.clear(); roomTimer=System.currentTimeMillis(); nextSpawn=0;
        x=W*.5f; y=H*.58f; maxHp=100+25*chapter+(adminHealth?1000:0); hp=maxHp; maxStamina=100; stamina=100; maxEnergy=100; energy=100;
        if(roomType==5){ screen=BOSS; spawnBoss(); }
        else {
            screen=ROOM;
            if(roomType==0)spawnWave(2+chapter);
            else if(roomType==1){ spawnWave(4+chapter*2); for(Enemy e:enemies)e.elite=true; }
            else if(roomType==2){loot.add(new Loot(W*.5f,H*.42f,0));}
            else if(roomType==3){roomCleared=true;}
            else if(roomType==4){screen=SHOP;}
        }
        beep(250+chapter*35,80); invalidate();
    }
    void spawnWave(int count){
        for(int i=0;i<count;i++){Enemy e=new Enemy(); e.kind=(i+chapter)%4; e.x=sx(150)+rng.nextFloat()*(W-sx(300)); e.y=sy(260)+rng.nextFloat()*H*.32f; e.max=34+chapter*8+(e.kind==3?25:0); e.hp=e.max; e.speed=42+chapter*5+e.kind*8; e.attackCd=700+rng.nextInt(700); enemies.add(e);}
    }
    void spawnBoss(){Enemy b=new Enemy();b.boss=true;b.kind=4;b.x=W*.5f;b.y=H*.27f;int[] hpByBoss={520,760,980,1180,1500};float[] spd={55,48,42,62,72};b.max=hpByBoss[Math.min(chapter,4)];b.hp=b.max;b.speed=spd[Math.min(chapter,4)];b.attackCd=900;b.bossStyle=chapter;enemies.add(b);bossIntro=true;bossPhase=1;bossLowShown=false;startDialogue("boss_pre_"+(chapter+1));}

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){W=w;H=h;}
    @Override protected void onDraw(Canvas c){super.onDraw(c); if(W<=0)return; if(screen==MENU)drawMenu(c); else if(screen==STORY)drawStory(c); else if(screen==MAP)drawMap(c); else if(screen==ROOM||screen==BOSS)drawBattle(c); else if(screen==DIALOGUE)drawDialogue(c); else if(screen==REWARD)drawReward(c); else if(screen==SHOP)drawShop(c); else if(screen==PAUSE){drawBattle(c);drawPause(c);} else if(screen==GAMEOVER)drawGameOver(c); else if(screen==VICTORY)drawVictory(c); else if(screen==ARCHIVE)drawArchive(c); else if(screen==EQUIP)drawEquip(c); else if(screen==ADMIN)drawAdmin(c); else if(screen==SECRET)drawSecretEnding(c);}

    void bg(Canvas c){
        c.drawColor(Color.rgb(10,8,13)); p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(24,20,28));
        float cell=sx(48); for(float yy=0;yy<H;yy+=cell)for(float xx=0;xx<W;xx+=cell)c.drawRect(xx+1,yy+1,xx+cell-1,yy+cell-1,p);
        p.setColor(Color.argb(24,255,255,255)); for(float yy=0;yy<H;yy+=cell)c.drawRect(0,yy,W,yy+2,p);
        p.setColor(Color.rgb(67,53,59));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sx(5));c.drawRoundRect(sx(24),sy(110),W-sx(24),H-sy(90),sx(24),sx(24),p);p.setStyle(Paint.Style.FILL);
        // torches
        for(int i=0;i<5;i++){float tx=sx(80+i*(W/sx(1)/6f)), ty=sy(150);p.setColor(Color.argb(40,255,160,80));c.drawCircle(tx,ty,sx(32),p);p.setColor(Color.rgb(240,150,75));c.drawCircle(tx,ty,sx(7),p);}
    }
    void title(Canvas c,String s,float y,float size){p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTextSize(sx(size));c.drawText(s,W/2,sy(y),p);}
    void text(Canvas c,String s,float x,float y,float size,int color){p.setTextAlign(Paint.Align.LEFT);p.setColor(color);p.setTextSize(sx(size));c.drawText(s,sx(x),sy(y),p);}
    void center(Canvas c,String s,float y,float size,int color){p.setTextAlign(Paint.Align.CENTER);p.setColor(color);p.setTextSize(sx(size));c.drawText(s,W/2,sy(y),p);}
    void panel(Canvas c,float l,float t,float r,float b,int color){p.setColor(color);c.drawRoundRect(sx(l),sy(t),sx(r),sy(b),sx(18),sx(18),p);}
    void button(Canvas c,float l,float t,float r,float b,String s,boolean active){panel(c,l,t,r,b,active?Color.rgb(105,61,67):Color.rgb(48,40,50));centerIn(c,s,(l+r)/2,(t+b)/2+10,28,Color.WHITE);}
    void centerIn(Canvas c,String s,float x,float y,float size,int color){p.setTextAlign(Paint.Align.CENTER);p.setColor(color);p.setTextSize(sx(size));c.drawText(s,sx(x),sy(y),p);}

    void drawMenu(Canvas c){
        bg(c); title(c,"ASHEN",330,92); center(c,"ОСКОЛКИ ПУСТОТЫ",380,26,Color.rgb(205,91,100));
        if(save.getInt("bosses",0)>0||save.getInt("chapter",0)>0)button(c,190,500,890,600,"ПРОДОЛЖИТЬ",true);
        button(c,190,625,890,725,"НОВАЯ ИГРА",false); button(c,190,750,890,850,"АРХИВ",false);
        center(c,"Ручной бой • один джойстик • без автобоя",930,22,Color.LTGRAY);
        center(c,"Оружие • заклинания • боссы • реликвии • сохранение",965,19,Color.GRAY);
        center(c,"v1.0 — полноценный кампейн-прототип",1030,17,Color.rgb(130,120,135));
    }
    void drawStory(Canvas c){bg(c); title(c,storyTitle,280,48); center(c,"Ты просыпаешься среди пепла. Имя забыто.",390,25,Color.LTGRAY); center(c,"В ладони — клинок, которого ты не помнишь.",430,25,Color.LTGRAY);
        panel(c,120,520,960,1080,Color.rgb(31,26,35));
        center(c,"Голос из-под камня",590,28,Color.rgb(220,170,125));
        center(c,"«Пять хранителей запечатали Пустоту.",660,24,Color.WHITE); center(c,"Но печать держится на чужой памяти.",700,24,Color.WHITE); center(c,"Если вспомнишь себя — мир проснётся.»",740,24,Color.WHITE);
        center(c,"Твоя цель: пройти пять владений и",820,22,Color.LTGRAY); center(c,"решить, что делать с сердцем Пустоты.",855,22,Color.LTGRAY);
        button(c,230,1150,850,1245,"ВОЙТИ В КАТАКОМБЫ",true);
    }
    void drawMap(Canvas c){bg(c); text(c,"ГЛАВА "+(chapter+1)+" / 5",45,70,22,Color.LTGRAY); text(c,chapters[chapter],45,105,30,Color.WHITE); text(c,"ОСКОЛКИ: "+coins,780,70,21,Color.rgb(240,190,110));
        center(c,"ПУТЬ",250,48,Color.rgb(210,170,125));
        float start=380, gap=150; for(int i=0;i<=roomsPerChapter;i++){float yy=start+i*gap; boolean done=i<room; boolean boss=i==roomsPerChapter; p.setColor(done?Color.rgb(100,160,120):(boss?Color.rgb(150,55,70):Color.rgb(95,80,100)));c.drawCircle(W/2,sy(yy),sx(boss?42:31),p); centerIn(c,boss?"Б":""+(i+1),W/(2*S()),yy+10,boss?26:22,Color.WHITE); if(i<roomsPerChapter){p.setColor(Color.rgb(70,55,70));p.setStrokeWidth(sx(8));c.drawLine(W/2,sy(yy+35),W/2,sy(yy+gap-35),p);}}
        panel(c,70,1080,1010,1370,Color.rgb(31,26,35)); text(c,"СНАРЯЖЕНИЕ",105,1130,24,Color.LTGRAY); text(c,"Оружие: "+weaponNames[weapon],105,1175,21,Color.WHITE); text(c,"Заклинание: "+spellNames[spell],105,1215,21,Color.rgb(170,205,255)); text(c,"Выбери свой стиль боя перед комнатой.",105,1260,18,Color.GRAY); button(c,680,1120,950,1200,"АРСЕНАЛ",true);
        button(c,260,1440,820,1535,"ВОЙТИ В СЛЕДУЮЩУЮ КОМНАТУ",true);
    }

    void drawEquip(Canvas c){
        bg(c); title(c,"АРСЕНАЛ",150,48); center(c,"Новые предметы открываются по главам",195,20,Color.LTGRAY);
        text(c,"ОРУЖИЕ",45,255,26,Color.rgb(220,170,125));
        for(int i=0;i<weaponNames.length;i++){int col=i%3,row=i/3;float l=35+col*350,t=280+row*145,r=l+330,b=t+125;boolean u=chapter>=weaponUnlock[i];panel(c,l,t,r,b,i==weapon?Color.rgb(90,55,62):(u?Color.rgb(35,29,39):Color.rgb(22,20,25)));text(c,(i+1)+". "+weaponNames[i],l+14,t+38,17,u?Color.WHITE:Color.DKGRAY);text(c,u?"Урон "+weaponDmg[i]+" • дальн. "+(int)weaponRange[i]:"ГЛАВА "+(weaponUnlock[i]+1),l+14,t+68,13,u?Color.LTGRAY:Color.GRAY);text(c,u?weaponDesc[i]:"Заблокировано",l+14,t+98,12,u?Color.LTGRAY:Color.DKGRAY);if(i==weapon)text(c,"ВЫБРАНО",l+220,t+112,12,Color.rgb(230,180,110));}
        text(c,"ЗАКЛИНАНИЯ",45,910,26,Color.rgb(170,205,255));
        for(int i=0;i<spellNames.length;i++){int col=i%3,row=i/3;float l=35+col*350,t=935+row*135,r=l+330,b=t+116;boolean u=chapter>=spellUnlock[i];panel(c,l,t,r,b,i==spell?Color.rgb(55,55,82):(u?Color.rgb(35,29,39):Color.rgb(22,20,25)));text(c,(i+1)+". "+spellNames[i],l+14,t+34,15,u?Color.WHITE:Color.DKGRAY);text(c,u?"Цена "+spellCost[i]+" • урон "+spellDmg[i]:"ГЛАВА "+(spellUnlock[i]+1),l+14,t+62,12,u?Color.LTGRAY:Color.GRAY);text(c,u?spellDesc[i]:"Заблокировано",l+14,t+91,11,u?Color.LTGRAY:Color.DKGRAY);if(i==spell)text(c,"ВЫБРАНО",l+220,t+105,12,Color.rgb(180,205,255));}
        button(c,250,1800,830,1885,"НАЗАД",true);
    }

    void drawBattle(Canvas c){bg(c); drawArenaDecor(c); drawTop(c); for(Projectile q:projectiles)drawProjectile(c,q); for(Enemy e:enemies)drawEnemy(c,e); for(Loot l:loot)drawLoot(c,l); drawPlayer(c); drawFx(c); if(screen==BOSS)drawBossBar(c); drawControls(c); if(roomCleared&&screen==ROOM)drawClearPrompt(c);}
    void drawArenaDecor(Canvas c){
        p.setColor(Color.rgb(43,34,43)); for(int i=0;i<9;i++){float xx=sx(70+i*120), yy=H-sy(270); c.drawRect(xx,yy,xx+sx(80),yy+sy(18),p);} 
        p.setColor(Color.rgb(57,46,52)); c.drawCircle(W*.15f,H*.27f,sx(30),p); c.drawCircle(W*.85f,H*.27f,sx(30),p);
    }
    void drawTop(Canvas c){
        text(c,chapters[chapter],35,52,19,Color.LTGRAY); text(c,"КОМНАТА "+Math.min(room+1,roomsPerChapter+1),35,82,23,Color.WHITE); text(c,"ОСКОЛКИ "+coins,800,52,18,Color.rgb(240,190,110));
        bar(c,35,100,690,124,hp,maxHp,Color.rgb(177,52,65)); bar(c,35,130,470,148,stamina,maxStamina,Color.rgb(70,145,200)); bar(c,35,154,470,172,energy,maxEnergy,Color.rgb(150,90,190));
        if(roomType==3){center(c,"ОТКРОВЕНИЕ",260,40,Color.rgb(220,170,125));center(c,"Здесь никто не ждёт. Только память.",310,24,Color.LTGRAY);}
    }
    void bar(Canvas c,float l,float t,float r,float b,float val,float max,int color){panel(c,l,t,r,b,Color.argb(100,0,0,0));p.setColor(color);c.drawRoundRect(sx(l),sy(t),sx(l+(r-l)*Math.max(0,Math.min(1,val/max))),sy(b),sx(7),sx(7),p);}
    void drawPlayer(Canvas c){
        drawShadow(c,x,y+sy(18)); Bitmap b=System.currentTimeMillis()<attackUntil?heroAttack:(System.currentTimeMillis()<hurtUntil?heroHurt:heroIdle); int frame=(int)((System.currentTimeMillis()/130)%4); drawFrame(c,b,frame,x,y,sx(2.8f));
        if(System.currentTimeMillis()<parryUntil){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sx(5));p.setColor(Color.rgb(210,235,255));c.drawCircle(x,y,sx(48),p);p.setStyle(Paint.Style.FILL);}
        if(System.currentTimeMillis()<dodgeUntil){p.setColor(Color.argb(80,170,220,255));c.drawCircle(x,y,sx(35),p);}
        // aim arrow from same joystick direction
        p.setColor(Color.argb(90,230,220,190));p.setStrokeWidth(sx(3));c.drawLine(x,y,x+dirX*sx(50),y+dirY*sx(50),p);
    }
    void drawEnemy(Canvas c,Enemy e){
        drawShadow(c,e.x,e.y+sy(18)); Bitmap b=e.boss?witch:(e.kind==1?knight:(e.kind==2?witch:knight)); if(e.boss)b=System.currentTimeMillis()<e.attackAnim?witchAttack:witch; else if(e.kind==1)b=System.currentTimeMillis()<e.attackAnim?knightAttack:knight; else if(e.kind==2)b=System.currentTimeMillis()<e.attackAnim?witchAttack:witch;
        float sc=e.boss?sx(4.2f):sx(2.7f); drawFrame(c,b,(int)((System.currentTimeMillis()/170)%4),e.x,e.y,sc); barAt(c,e.x,e.y-sy(e.boss?72:52),e.x-sx(e.boss?85:38),e.x+sx(e.boss?85:38),e.hp,e.max,e.boss?Color.rgb(185,55,75):Color.rgb(125,155,170));
        if(e.elite&&!e.boss){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sx(3));p.setColor(Color.rgb(220,170,90));c.drawCircle(e.x,e.y,sx(34),p);p.setStyle(Paint.Style.FILL);}
    }
    void barAt(Canvas c,float cx,float cy,float l,float r,float val,float max,int color){p.setColor(Color.argb(110,0,0,0));c.drawRoundRect(l,cy,r,cy+sy(8),sx(4),sx(4),p);p.setColor(color);c.drawRoundRect(l,cy,l+(r-l)*Math.max(0,val/max),cy+sy(8),sx(4),sx(4),p);}
    void drawShadow(Canvas c,float xx,float yy){p.setAlpha(100);RectF d=new RectF(xx-sx(26),yy-sy(8),xx+sx(26),yy+sy(8));c.drawBitmap(shadow,null,d,px);p.setAlpha(255);}
    void drawFrame(Canvas c,Bitmap b,int frame,float xx,float yy,float scale){int fw=Math.min(32,b.getWidth()),fh=Math.min(32,b.getHeight());int count=Math.max(1,b.getWidth()/fw);frame=Math.max(0,Math.min(frame,count-1));Rect src=new Rect(frame*fw,0,frame*fw+fw,fh);float ww=fw*scale,hh=fh*scale;c.drawBitmap(b,src,new RectF(xx-ww/2,yy-hh/2,xx+ww/2,yy+hh/2),px);}
    void drawProjectile(Canvas c,Projectile q){p.setColor(q.enemy?Color.rgb(180,75,95):Color.rgb(210,160,90));p.setShadowLayer(sx(12),0,0,q.enemy?Color.MAGENTA:Color.YELLOW);c.drawCircle(q.x,q.y,sx(q.big?12:7),p);p.clearShadowLayer();}
    void drawLoot(Canvas c,Loot l){p.setColor(l.taken?Color.DKGRAY:Color.rgb(205,155,75));p.setShadowLayer(sx(18),0,0,Color.rgb(220,150,80));c.drawCircle(l.x,l.y,sx(26),p);p.clearShadowLayer();centerIn(c,l.type==0?"✦":"?",l.x/S(),l.y/S()+10,25,Color.WHITE);}
    void drawFx(Canvas c){for(Fx f:fx){float a=1f-(System.currentTimeMillis()-f.birth)/(float)f.life;p.setColor(Color.argb((int)(Math.max(0,a)*180),f.colorR,f.colorG,f.colorB));c.drawCircle(f.x,f.y,sx(f.size*(1+(1-a))),p);}}
    void drawControls(Canvas c){
        float baseX=sx(145),baseY=H-sy(165);p.setColor(Color.argb(45,255,255,255));c.drawCircle(baseX,baseY,sx(105),p);p.setColor(Color.argb(80,255,255,255));float knobX=moveTouch?joyX:baseX,knobY=moveTouch?joyY:baseY;c.drawCircle(knobX,knobY,sx(36),p);
        action(c,W-sx(125),H-sy(175),sx(56),"⚔",0); action(c,W-sx(70),H-sy(290),sx(52),"↯",1); action(c,W-sx(205),H-sy(290),sx(52),"✦",2); action(c,W-sx(205),H-sy(150),sx(52),"◈",3); if(screen!=BOSS) action(c,W-sx(315),H-sy(225),sx(46),"i",4);
        centerIn(c,weaponNames[weapon],W/S()-190,170,17,Color.LTGRAY); centerIn(c,spellNames[spell],W/S()-180,195,15,Color.rgb(180,205,255));
    }
    void action(Canvas c,float xx,float yy,float rr,String s,int i){p.setColor(pressed[i]?Color.argb(150,190,150,155):Color.argb(55,255,255,255));c.drawCircle(xx,yy,rr,p);centerIn(c,s,xx/S(),yy/S()+10,30,Color.WHITE);}
    void drawClearPrompt(Canvas c){panel(c,210,700,870,920,Color.argb(225,20,16,25));center(c,"КОМНАТА ОЧИЩЕНА",770,30,Color.WHITE);center(c,"Нажми i для продолжения",820,21,Color.LTGRAY);}
    void drawBossBar(Canvas c){if(enemies.size()==0)return;Enemy b=enemies.get(0);panel(c,170,190,910,245,Color.argb(180,15,12,18));center(c,bossNames[chapter],225,22,Color.WHITE);bar(c,195,205,885,225,b.hp,b.max,Color.rgb(190,55,75)); center(c,"ФАЗА "+bossPhase,260,18,Color.GRAY);}

    void drawReward(Canvas c){bg(c);title(c,"НАГРАДА",260,52);center(c,"Выбери одно усиление",320,24,Color.LTGRAY);String[] opts={"+25 МАКС. HP","+20 МАКС. ЭНЕРГИИ","+12 УРОН ОРУЖИЯ"};for(int i=0;i<3;i++){float y=470+i*230;panel(c,120,y,960,y+160,Color.rgb(35,29,39));centerIn(c,(i+1)+"",180,y+65,38,Color.rgb(220,170,125));text(c,opts[i],250,y+70,27,Color.WHITE);text(c,i==0?"Здоровье":"Сила билда",250,y+108,18,Color.LTGRAY);}center(c,"Нажми на одну из карт",1210,21,Color.GRAY);}
    void drawShop(Canvas c){bg(c);title(c,"ЛАВКА ПЕПЕЛЬЩИКА",240,48);center(c,"Осколки: "+coins,300,24,Color.rgb(240,190,110));String[] a={"Улучшить оружие","Улучшить заклинание","Купить реликвию","Выйти"};for(int i=0;i<4;i++)button(c,150,430+i*170,930,545+i*170,a[i],i==0);center(c,"Каждая покупка сохраняется",1170,20,Color.GRAY);}
    void drawPause(Canvas c){panel(c,120,420,960,1110,Color.argb(235,12,10,16));title(c,"ПАУЗА",570,52);button(c,220,680,860,770,"ПРОДОЛЖИТЬ",true);button(c,220,800,860,890,"СОХРАНИТЬ",false);button(c,220,920,860,1010,"В МЕНЮ",false);}
    void drawGameOver(Canvas c){bg(c);title(c,"ПЕПЕЛ ПОГЛОТИЛ ТЕБЯ",430,50);center(c,"Смерть не отменяет найденные реликвии.",510,23,Color.LTGRAY);center(c,"Попробуй снова — Пустота помнит твои попытки.",550,21,Color.GRAY);button(c,200,720,880,820,"ВОЗРОДИТЬСЯ",true);button(c,200,850,880,950,"В МЕНЮ",false);}
    void drawVictory(Canvas c){bg(c);title(c,"ПУСТОТА ОТКРЫТА",330,56);center(c,"Астер пал. Но дверь не закрылась.",430,26,Color.LTGRAY);center(c,"Теперь ты можешь выбрать судьбу Пепла.",475,24,Color.WHITE);panel(c,110,590,970,1120,Color.rgb(31,26,35));center(c,"ИСТИННАЯ КОНЦОВКА",660,30,Color.rgb(220,170,125));center(c,"Ты вспоминаешь своё имя.",740,24,Color.WHITE);center(c,"Ты был первым, кто запечатал Пустоту.",780,23,Color.LTGRAY);center(c,"И последним, кто способен решить её судьбу.",820,23,Color.LTGRAY);button(c,240,930,840,1020,"НАЧАТЬ НОВЫЙ ЦИКЛ",true);}
    void drawArchive(Canvas c){bg(c);title(c,"АРХИВ ПАМЯТИ",220,50);text(c,"ОТКРЫТО БОССОВ: "+totalBossesDefeated+" / 5",100,340,25,Color.WHITE);for(int i=0;i<5;i++){boolean open=i<totalBossesDefeated;panel(c,100,390+i*150,980,510+i*150,open?Color.rgb(44,35,43):Color.rgb(25,22,29));text(c,(i+1)+". "+bossNames[i],130,445+i*150,22,open?Color.WHITE:Color.GRAY);text(c,open?bossLore[i]:"Запись скрыта",130,480+i*150,16,open?Color.LTGRAY:Color.DKGRAY);}button(c,260,1180,820,1270,"НАЗАД",true);}

    void drawAdmin(Canvas c){
        bg(c);
        title(c,"АДМИН-ПАНЕЛЬ",190,48);
        center(c,"КОД ПРИНЯТ: nkw04",245,20,Color.rgb(120,190,130));
        center(c,"Секретные функции",285,18,Color.GRAY);
        adminButton(c,90,360,990,490,"МНОГОЗАРЯДНАЯ МАГИЯ",adminSpellBurst,
                "Одно заклинание → десятки снарядов во все стороны");
        adminButton(c,90,530,990,660,"БЕСКОНЕЧНАЯ ЖИЗНЬ",adminHealth,
                "Максимальное здоровье увеличено и восстанавливается");
        adminButton(c,90,700,990,830,"ВЫХОД ЗА ПРЕДЕЛЫ",adminFreeWorld,
                "Позволяет покинуть арену. Вне мира заклинание открывает секретную концовку");
        panel(c,90,900,990,1080,Color.rgb(31,26,35));
        center(c,"СЕКРЕТНАЯ КОНЦОВКА",960,25,Color.rgb(120,220,150));
        center(c,"Выйди за границы мира и",1010,19,Color.LTGRAY);
        center(c,"нажми ✦. Дальше Пепел ответит.",1045,19,Color.WHITE);
        button(c,250,1180,830,1270,"НАЗАД",true);
    }
    void adminButton(Canvas c,float l,float t,float r,float b,String name,boolean on,String desc){
        panel(c,l,t,r,b,on?Color.rgb(55,82,61):Color.rgb(35,29,39));
        text(c,name,l+25,t+43,23,Color.WHITE);
        text(c,on?"ВКЛ":"ВЫКЛ",r-105,t+43,18,on?Color.rgb(130,230,145):Color.GRAY);
        text(c,desc,l+25,t+88,14,Color.LTGRAY);
    }
    void drawSecretEnding(Canvas c){
        long elapsed=System.currentTimeMillis()-secretStart;
        float phase=Math.min(1f,elapsed/9000f);
        c.drawColor(Color.rgb(5,8,6));
        // Cracked world halves
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(28,30,29));
        Path left=new Path(); left.moveTo(0,0); left.lineTo(W*.47f,0); left.lineTo(W*.43f,H*.35f);
        left.lineTo(W*.47f,H*.68f); left.lineTo(W*.40f,H); left.lineTo(0,H); left.close(); c.drawPath(left,p);
        Path right=new Path(); right.moveTo(W*.53f,0); right.lineTo(W,0); right.lineTo(W,H); right.lineTo(W*.60f,H); right.lineTo(W*.57f,H*.68f); right.lineTo(W*.53f,H*.35f); right.close(); c.drawPath(right,p);
        // Green energy grows as the shards reunite
        float cx=W/2f, cy=H*.55f;
        if(phase<.58f){
            float gap=1f-phase/.58f;
            p.setColor(Color.argb(220,90,255,130));
            c.drawCircle(cx-W*.28f*gap,cy,sx(28+50*phase),p);
            c.drawCircle(cx+W*.28f*gap,cy,sx(28+50*phase),p);
            p.setColor(Color.argb(90,80,255,120));
            for(int i=0;i<18;i++){double a=i*Math.PI*2/18;float rr=sx(120+80*phase);c.drawCircle(cx+(float)Math.cos(a)*rr,cy+(float)Math.sin(a)*rr,sx(5+8*phase),p);}
        }else{
            secretHeartScale=Math.min(1.25f,.7f+(phase-.58f)*1.3f);
            p.setColor(Color.argb(65,60,255,110));c.drawCircle(cx,cy,sx(190*secretHeartScale),p);
            p.setColor(Color.rgb(95,255,135));c.drawCircle(cx,cy,sx(54*secretHeartScale),p);
            // heart
            Path heart=new Path();float hs=sx(38*secretHeartScale);
            heart.moveTo(cx,cy+hs*1.25f);heart.cubicTo(cx-hs*2.1f,cy-hs*.15f,cx-hs*1.2f,cy-hs*1.8f,cx,cy-hs*.75f);
            heart.cubicTo(cx+hs*1.2f,cy-hs*1.8f,cx+hs*2.1f,cy-hs*.15f,cx,cy+hs*1.25f);
            c.drawPath(heart,p);
            p.setColor(Color.argb(100,80,255,120));p.setStrokeWidth(sx(7));
            for(int i=0;i<16;i++){double a=i*Math.PI*2/16;float rr=sx(120+40*(float)Math.sin(elapsed*.002+i));c.drawLine(cx,cy,cx+(float)Math.cos(a)*rr,cy+(float)Math.sin(a)*rr,p);}
        }
        if(phase>.72f){
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Color.WHITE);p.setTextSize(sx(42));c.drawText("СЕКРЕТНАЯ КОНЦОВКА",W/2,sy(1180),p);
            p.setTextSize(sx(22));p.setColor(Color.rgb(150,255,175));c.drawText("Пепел раскололся. Сердце вернулось.",W/2,sy(1240),p);
            p.setColor(Color.LTGRAY);c.drawText("Ты вышел за пределы мира — и мир ответил.",W/2,sy(1280),p);
        }
        if(elapsed>10500){
            button(c,250,1430,830,1520,"В МЕНЮ",true);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        int a=e.getActionMasked();
        int idx=e.getActionIndex();
        int id=e.getPointerId(idx);
        float tx=e.getX(idx), ty=e.getY(idx);

        if(a==MotionEvent.ACTION_DOWN){
            if(screen==DIALOGUE){ nextDialogue(); return true; }
            if(screen==SECRET){
                if(System.currentTimeMillis()-secretStart>10500 && ty>sy(1400)){screen=MENU;invalidate();}
                return true;
            }
            if(screen==ADMIN){
                if(ty>sy(330)&&ty<sy(510)){adminSpellBurst=!adminSpellBurst;saveAll();invalidate();return true;}
                if(ty>sy(510)&&ty<sy(680)){adminHealth=!adminHealth;saveAll();invalidate();return true;}
                if(ty>sy(680)&&ty<sy(850)){adminFreeWorld=!adminFreeWorld;saveAll();invalidate();return true;}
                if(ty>sy(1140)){screen=MENU;invalidate();return true;}
                return true;
            }
            if(screen==MENU){
                // Hidden admin access: tap the version line five times, then enter the code.
                if(ty>sy(990)&&ty<sy(1075)){
                    long now=System.currentTimeMillis();
                    if(now-adminTapWindow>2200) adminTapCount=0;
                    adminTapWindow=now; adminTapCount++;
                    if(adminTapCount>=5){adminTapCount=0; showAdminCodeDialog(); return true;}
                    return true;
                }
                if(ty>sy(470)&&ty<sy(620)&&save.getInt("chapter",0)>0){continueGame();return true;}
                if(ty>sy(610)&&ty<sy(760)){newGame();return true;}
                if(ty>sy(740)&&ty<sy(880)){screen=ARCHIVE;invalidate();return true;}
            } else if(screen==STORY){
                if(ty>sy(1080)){startChapter();return true;}
            } else if(screen==MAP){
                if(tx>sx(620)&&tx<sx(1000)&&ty>sy(1090)&&ty<sy(1230)){screen=EQUIP;invalidate();return true;}
                if(ty>sy(1360)){enterRoom();return true;}
            } else if(screen==EQUIP){
                if(ty>sy(275)&&ty<sy(880)){int col=Math.max(0,Math.min(2,(int)(tx/(W/3f))));int row=(int)((ty-sy(280))/sy(145));int i=row*3+col;if(i>=0&&i<weaponNames.length&&chapter>=weaponUnlock[i]){weapon=i;saveAll();invalidate();}return true;}
                if(ty>sy(925)&&ty<sy(1785)){int col=Math.max(0,Math.min(2,(int)(tx/(W/3f))));int row=(int)((ty-sy(935))/sy(135));int i=row*3+col;if(i>=0&&i<spellNames.length&&chapter>=spellUnlock[i]){spell=i;saveAll();invalidate();}return true;}
                if(ty>sy(1780)){screen=MAP;invalidate();return true;}
            } else if(screen==ROOM||screen==BOSS){
                if(tx>W-sx(100) && ty<sy(110)){screen=PAUSE;saveAll();invalidate();return true;}
                if(screen==BOSS&&bossIntro){bossIntro=false;invalidate();return true;}
                if(tx<W*.48f && ty>H-sy(330)){
                    moveTouch=true; moveId=id; joyX=tx; joyY=ty; updateDirection(tx,ty); return true;
                }
                int b=buttonAt(tx,ty);
                if(b>=0){
                    pressed[b]=true; buttonPointerId[b]=id;
                    if(b==4) advanceRoom(); else trigger(b);
                    invalidate(); return true;
                }
                if(screen==BOSS&&bossIntro){bossIntro=false;invalidate();return true;}
            } else if(screen==REWARD){chooseReward((int)((ty-sy(430))/sy(230)));return true;}
            else if(screen==SHOP){int row=(int)((ty-sy(400))/sy(170));buy(row);return true;}
            else if(screen==PAUSE){
                if(ty>sy(650)&&ty<sy(790)){screen=ROOM;invalidate();return true;}
                if(ty>sy(790)&&ty<sy(910)){saveAll();beep(650,60);return true;}
                if(ty>sy(900)&&ty<sy(1040)){saveAll();screen=MENU;invalidate();return true;}
            } else if(screen==GAMEOVER){
                if(ty>sy(690)&&ty<sy(850)){enterRoom();screen=ROOM;return true;}
                if(ty>sy(830)&&ty<sy(990)){screen=MENU;invalidate();return true;}
            } else if(screen==VICTORY){if(ty>sy(900)){newGame();return true;}}
            else if(screen==ARCHIVE){if(ty>sy(1130)){screen=MENU;invalidate();return true;}}
        } else if(a==MotionEvent.ACTION_POINTER_DOWN){
            // A second finger is ONLY allowed to press an action button.
            // It must never create or steal the movement joystick.
            if(screen==ROOM||screen==BOSS){
                int b=buttonAt(tx,ty);
                if(b>=0){
                    pressed[b]=true; buttonPointerId[b]=id;
                    if(b==4) advanceRoom(); else trigger(b);
                    invalidate(); return true;
                }
            }
        } else if(a==MotionEvent.ACTION_MOVE){
            if(moveTouch){
                int j=e.findPointerIndex(moveId);
                if(j>=0){
                    joyX=e.getX(j); joyY=e.getY(j); updateDirection(joyX,joyY);
                }
            }
        } else if(a==MotionEvent.ACTION_POINTER_UP){
            if(id==moveId){
                // Keep the joystick alive if another finger is still holding it.
                moveTouch=false; moveId=-1;
                for(int i=0;i<e.getPointerCount();i++){
                    int otherId=e.getPointerId(i);
                    if(otherId==id) continue;
                    float ox=e.getX(i), oy=e.getY(i);
                    if(ox<W*.48f && oy>H-sy(330)){
                        moveTouch=true; moveId=otherId; joyX=ox; joyY=oy; updateDirection(ox,oy); break;
                    }
                }
            }
            for(int b=0;b<pressed.length;b++){
                if(buttonPointerId[b]==id){pressed[b]=false;buttonPointerId[b]=-1;}
            }
            invalidate();
        } else if(a==MotionEvent.ACTION_UP || a==MotionEvent.ACTION_CANCEL){
            if(a==MotionEvent.ACTION_UP && id==moveId){moveTouch=false;moveId=-1;}
            if(a==MotionEvent.ACTION_CANCEL){moveTouch=false;moveId=-1;}
            for(int b=0;b<pressed.length;b++){
                if(a==MotionEvent.ACTION_CANCEL || buttonPointerId[b]==id){pressed[b]=false;buttonPointerId[b]=-1;}
            }
            invalidate();
        }
        return true;
    }
    void showAdminCodeDialog(){
        final EditText input=new EditText(getContext());
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("Код");
        AlertDialog d=new AlertDialog.Builder(getContext())
            .setTitle("ПАНЕЛЬ АДМИНИСТРАТОРА")
            .setMessage("Введи секретный код")
            .setView(input)
            .setNegativeButton("ОТМЕНА",null)
            .setPositiveButton("ПРОВЕРИТЬ",null)
            .create();
        d.setOnShowListener(v -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            if("nkw04".equals(input.getText().toString().trim())){
                adminUnlocked=true; saveAll(); screen=ADMIN; d.dismiss(); invalidate();
            }else{
                input.setError("Неверный код");
            }
        }));
        d.show();
    }
    void updateDirection(float tx,float ty){float bx=sx(145),by=H-sy(165);float dx=tx-bx,dy=ty-by;float n=(float)Math.hypot(dx,dy);if(n>sx(16)){dirX=dx/n;dirY=dy/n;}}
    int buttonAt(float tx,float ty){float[][] q={{W-sx(125),H-sy(175)},{W-sx(70),H-sy(290)},{W-sx(205),H-sy(290)},{W-sx(205),H-sy(150)},{W-sx(315),H-sy(225)}};float[] r={56,52,52,52,46};int count=screen==BOSS?4:5;for(int i=0;i<count;i++)if(Math.hypot(tx-q[i][0],ty-q[i][1])<sx(r[i]+8))return i;return -1;}

    void trigger(int b){if(screen!=ROOM&&screen!=BOSS)return;long now=System.currentTimeMillis();if(b==0)attack();else if(b==1)dodge();else if(b==2)castSpell();else if(b==3)parry();}
    void attack(){long now=System.currentTimeMillis();if(now<attackUntil)return;int w=weapon;attackUntil=now+(long)Math.max(105,weaponCd[w]-weaponLevel*12);combo=(now<comboUntil)?(combo%3)+1:1;comboUntil=now+700;int dmg=weaponDmg[w]+weaponLevel*8+(combo==3?12:0);if(w==6||w==11){projectiles.add(new Projectile(x+dirX*sx(35),y+dirY*sy(35),dirX*(w==6?620:540),dirY*(w==6?620:540),false,w==11,dmg+(w==11?18:10)));beep(w==6?430:700,55);return;}float range=sx(weaponRange[w]+weaponLevel*4);float arc=(w==2?0.78f:(w==5?0.42f:(w==9?0.34f:0.22f)));for(Enemy e:new ArrayList<>(enemies)){float dx=e.x-x,dy=e.y-y,d=(float)Math.hypot(dx,dy);if(d<range){float dot=(dx*dirX+dy*dirY)/(d+.01f);if(dot>Math.cos(arc)){float dealt=dmg;if(w==9&&rng.nextInt(100)<35)dealt*=2f;if(w==10)dealt*=1.35f;hitEnemy(e,dealt);if(w==4)e.stunUntil=now+700;if(w==7&&e.hp<=0)hp=Math.min(maxHp,hp+14);}}}if(w==3){for(Enemy e:new ArrayList<>(enemies)){float d=dist(e.x,e.y,x,y);if(d<sx(95))hitEnemy(e,dmg*.7f);}}else if(w==4){fx.add(new Fx(x+dirX*sx(45),y+dirY*sx(45),now,220,60,220,170,80));for(Enemy e:new ArrayList<>(enemies))if(dist(e.x,e.y,x,y)<sx(145))hitEnemy(e,dmg*.45f);}fx.add(new Fx(x+dirX*sx(45),y+dirY*sx(45),now,80,36,245,190,120));beep(190+combo*45,45);}

    void hitEnemy(Enemy e,float dmg){long now=System.currentTimeMillis();if(e.markUntil>now)dmg*=1.55f;if(now<weaponBuffUntil)dmg*=1.15f;if(e.freezeUntil>now)dmg*=1.1f;e.hp-=dmg;e.attackAnim=now+180;fx.add(new Fx(e.x,e.y,now,120,26,220,90,90));if(e.hp<=0){coins+=e.boss?90:8+chapter*2;kills++;if(e.boss){totalBossesDefeated++;saveAll();if(chapter>=4){startDialogue("boss_death_"+(chapter+1));beep(80,400);}else{chapter++;room=0;saveAll();screen=REWARD;beep(100,300);}}else{enemies.remove(e);if(enemies.isEmpty())roomCleared=true;}}else if(e.boss&&bossPhase==1&&e.hp<=e.max*.5f){bossPhase=2;startDialogue("boss_phase2_"+(chapter+1));}else if(e.boss&&bossPhase==2&&e.hp<=e.max*.2f&&!bossLowShown){bossLowShown=true;startDialogue("boss_low_"+(chapter+1));}}

    void dodge(){long now=System.currentTimeMillis();if(now<dodgeUntil||stamina<24)return;stamina-=24;dodgeUntil=now+280;invulnUntil=now+360;x+=dirX*sx(105);y+=dirY*sy(105);clampPlayer();fx.add(new Fx(x,y,now,180,24,150,210,255));beep(650,50);}
    void castSpell(){long now=System.currentTimeMillis();int cost=spellCost[spell];if(chapter<spellUnlock[spell]||now<spellUntil||energy<cost)return;
        if(adminFreeWorld && outsideWorld()){
            secretStart=now; screen=SECRET; projectiles.clear(); enemies.clear(); fx.clear(); beep(70,500); invalidate(); return;
        }
        energy-=cost;spellUntil=now+(long)Math.max(260,620-spellLevel*35);float dx=dirX,dy=dirY;
        if(adminSpellBurst){
            int count=36; float dmg=Math.max(35,spellDmg[spell])+spellLevel*10;
            for(int i=0;i<count;i++){double a=i*Math.PI*2/count;float speed=300+rng.nextFloat()*260;
                projectiles.add(new Projectile(x+(float)Math.cos(a)*sx(32),y+(float)Math.sin(a)*sy(32),
                    (float)Math.cos(a)*speed,(float)Math.sin(a)*speed,false,i%3==0,dmg));
            }
        }
        switch(spell){case 0:projectiles.add(new Projectile(x+dx*sx(35),y+dy*sy(35),dx*500,dy*500,false,false,spellDmg[spell]+spellLevel*8));break;case 1:projectiles.add(new Projectile(x+dx*sx(35),y+dy*sy(35),dx*440,dy*440,false,false,spellDmg[spell]+spellLevel*7));break;case 2:for(int i=-1;i<=1;i++){float a=(float)(Math.atan2(dy,dx)+i*.18);projectiles.add(new Projectile(x+dx*sx(30),y+dy*sy(30),(float)Math.cos(a)*480,(float)Math.sin(a)*480,false,false,spellDmg[spell]+spellLevel*6));}break;case 3:for(Enemy e:new ArrayList<>(enemies))if(dist(e.x,e.y,x,y)<sx(190))hitEnemy(e,spellDmg[spell]+spellLevel*9);fx.add(new Fx(x,y,now,280,110,120,190,255));break;case 4:for(int i=1;i<=3;i++){Projectile q=new Projectile(x+dx*sx(80+i*35),y+dy*sy(80+i*35),dx*160,dy*160,false,true,spellDmg[spell]+spellLevel*15);q.delay=i*180;projectiles.add(q);}break;case 5:hp=Math.min(maxHp,hp+32+spellLevel*8);fx.add(new Fx(x,y,now,350,55,170,130,230));break;case 6:for(int i=-1;i<=1;i++){float a=(float)(Math.atan2(dy,dx)+i*.28);projectiles.add(new Projectile(x+dx*sx(30),y+dy*sy(30),(float)Math.cos(a)*430,(float)Math.sin(a)*430,false,true,spellDmg[spell]+spellLevel*7));}break;case 7:{Enemy e=nearestEnemy(300);if(e!=null){e.freezeUntil=now+2200;hitEnemy(e,spellDmg[spell]+spellLevel*5);}}break;case 8:{ArrayList<Enemy> list=new ArrayList<>(enemies);Collections.sort(list,(a,b)->Float.compare(dist(a.x,a.y,x,y),dist(b.x,b.y,x,y)));int n=Math.min(4,list.size());for(int i=0;i<n;i++)if(dist(list.get(i).x,list.get(i).y,x,y)<sx(500))hitEnemy(list.get(i),(spellDmg[spell]+spellLevel*8)*(1f-i*.18f));}break;case 9:projectiles.add(new Projectile(x+dx*sx(150),y+dy*sy(150),0,0,false,true,spellDmg[spell]+spellLevel*10,now+1800));break;case 10:invulnUntil=now+450;x+=dx*sx(150);y+=dy*sy(150);clampPlayer();for(Enemy e:new ArrayList<>(enemies))if(dist(e.x,e.y,x-dx*sx(80),y-dy*sy(80))<sx(90))hitEnemy(e,spellDmg[spell]+spellLevel*7);break;case 11:{float gx=x+dx*sx(180),gy=y+dy*sy(180);for(Enemy e:enemies)if(dist(e.x,e.y,gx,gy)<sx(260)){e.pullUntil=now+900;e.pullX=gx;e.pullY=gy;hitEnemy(e,spellDmg[spell]+spellLevel*5);}fx.add(new Fx(gx,gy,now,900,80,120,60,180));}break;case 12:{Enemy e=nearestEnemy(380);if(e!=null)e.markUntil=now+5000;}break;case 13:if(hp>20){hp-=20;weaponBuffUntil=now+7000;}break;case 14:shieldUntil=now+4500;invulnUntil=now+500;break;case 15:projectiles.add(new Projectile(x+dx*sx(170),y+dy*sy(170),0,0,false,true,spellDmg[spell]+spellLevel*4,now+3000));break;case 16:{float gx=x+dx*sx(180),gy=y+dy*sy(180);for(Enemy e:new ArrayList<>(enemies))if(dist(e.x,e.y,gx,gy)<sx(300)){e.pullUntil=now+1200;e.pullX=gx;e.pullY=gy;hitEnemy(e,spellDmg[spell]+spellLevel*9);}}break;case 17:hp=Math.min(maxHp,hp+40);for(Enemy e:new ArrayList<>(enemies))if(dist(e.x,e.y,x,y)<sx(240))hitEnemy(e,spellDmg[spell]+spellLevel*12);break;}beep(600+spell*35,75);}
    float dist(float ax,float ay,float bx,float by){return (float)Math.hypot(ax-bx,ay-by);} Enemy nearestEnemy(float range){Enemy best=null;float bd=range;for(Enemy e:enemies){float d=dist(e.x,e.y,x,y);if(d<bd){bd=d;best=e;}}return best;}

    void parry(){long now=System.currentTimeMillis();if(now<parryUntil||stamina<14)return;stamina-=14;parryUntil=now+240;beep(1150,50);}
    void advanceRoom(){if(screen==BOSS){if(enemies.isEmpty()){chapter++;room=0;saveAll();screen=chapter>=5?VICTORY:MAP;}return;}if(!roomCleared&&roomType!=2&&roomType!=3)return;if(roomType==2&&!loot.isEmpty()&&!loot.get(0).taken){loot.get(0).taken=true;coins+=30+chapter*10;beep(620,80);return;}room++;saveAll();if(room>roomsPerChapter){screen=BOSS;enemies.clear();spawnBoss();}else{screen=MAP;}invalidate();}
    void chooseReward(int idx){if(idx<0||idx>2)return;if(idx==0){maxHp+=25;hp=maxHp;}else if(idx==1){maxEnergy+=20;energy=maxEnergy;}else{weaponLevel++;}saveAll();room=0;screen=MAP;beep(500+idx*120,80);invalidate();}
    void buy(int row){if(row<0||row>3)return;if(row==0&&coins>=40){coins-=40;weaponLevel++;}else if(row==1&&coins>=45){coins-=45;spellLevel++;}else if(row==2&&coins>=70){coins-=70;for(int i=0;i<relics.length;i++)if(!relics[i]){relics[i]=true;break;}}else if(row==3){room++;saveAll();screen=MAP;}saveAll();invalidate();}

    void update(){long now=System.currentTimeMillis();float dt=Math.min(.04f,(System.nanoTime()-last)/1e9f);last=System.nanoTime();
        if(screen==ROOM||screen==BOSS){
            if(moveTouch){float bx=sx(145),by=H-sy(165),dx=joyX-bx,dy=joyY-by,n=(float)Math.hypot(dx,dy);if(n>sx(12)){float m=Math.min(1,n/sx(105));x+=dx/n*220*m*dt;y+=dy/n*220*m*dt;updateDirection(joyX,joyY);}}
            clampPlayer(); stamina=Math.min(maxStamina,stamina+32*dt); energy=Math.min(maxEnergy,energy+10*dt);
            for(Projectile q:new ArrayList<>(projectiles)){if(now<q.delay+q.birth)continue;q.x+=q.vx*dt;q.y+=q.vy*dt;q.life-=dt;if(q.life<=0||q.x<0||q.x>W||q.y<sy(100)||q.y>H-sy(260)){projectiles.remove(q);continue;}if(!q.enemy){for(Enemy e:new ArrayList<>(enemies)){if(Math.hypot(q.x-e.x,q.y-e.y)<sx(q.big?55:34)){hitEnemy(e,q.damage);projectiles.remove(q);break;}}}else if(Math.hypot(q.x-x,q.y-y)<sx(28)){if(now>invulnUntil)takeDamage(q.damage);projectiles.remove(q);}}
            for(Enemy e:new ArrayList<>(enemies))updateEnemy(e,dt,now);
            if(screen==BOSS&&enemies.isEmpty()){bossIntro=false;roomCleared=true;}
            if(roomType==0&&roomCleared){/* wait */}
        }
        for(Fx f:new ArrayList<>(fx))if(now-f.birth>f.life)fx.remove(f);
        invalidate();
    }
    void updateEnemy(Enemy e,float dt,long now){
        if(e.pullUntil>now){float px=e.pullX-e.x,py=e.pullY-e.y,d=(float)Math.hypot(px,py);if(d>8){e.x+=px/d*160*dt;e.y+=py/d*160*dt;}}
        if(e.freezeUntil>now||e.stunUntil>now)return;
        if(e.boss){float phase=e.hp/e.max;if(phase<.5f)e.speed=(e.bossStyle==1?58:e.bossStyle==3?72:82);}
        float dx=x-e.x,dy=y-e.y,d=(float)Math.hypot(dx,dy);
        if(!e.boss && e.kind==2 && d<sx(260)){e.x-=dx/(d+.01f)*e.speed*.35f*dt;e.y-=dy/(d+.01f)*e.speed*.35f*dt;}
        else if(d>sx(e.boss?125:58)){e.x+=dx/(d+.01f)*e.speed*dt;e.y+=dy/(d+.01f)*e.speed*dt;}
        long interval=e.boss?(e.bossStyle==2?1000:(e.bossStyle==1?760:680)):(e.kind==3?820:(e.kind==2?1250:1100-e.kind*80));
        if(now>e.attackCd){
            e.attackCd=now+interval;e.attackAnim=now+250;
            if(e.boss){bossAttack(e);return;}
            if(e.kind==0){ // melee
                if(d<sx(105)){if(now>invulnUntil)takeDamage(8+chapter*2);else e.hp-=10;}
            } else if(e.kind==1){ // shield knight: charge + ring
                if(d<sy(150)){float vx=dx/(d+.01f),vy=dy/(d+.01f);e.x+=vx*sx(65);e.y+=vy*sy(65);if(now>invulnUntil)takeDamage(13+chapter*2);}
                for(int i=0;i<4;i++){double a=i*Math.PI/2;projectiles.add(new Projectile(e.x,e.y,(float)Math.cos(a)*150,(float)Math.sin(a)*150,true,false,8+chapter));}
            } else if(e.kind==2){ // caster: aimed shot + side step
                Projectile q=new Projectile(e.x,e.y,dx/(d+.01f)*300,dy/(d+.01f)*300,true,false,11+chapter*3);q.big=true;projectiles.add(q);
            } else { // berserker: three-shot rush
                for(int i=-1;i<=1;i++){float a=(float)(Math.atan2(dy,dx)+i*.16);projectiles.add(new Projectile(e.x,e.y,(float)Math.cos(a)*330,(float)Math.sin(a)*330,true,false,10+chapter*3));}
                if(d<sx(125)&&now>invulnUntil)takeDamage(16+chapter*2);
            }
        }
    }

    void bossAttack(Enemy b){long now=System.currentTimeMillis();int style=b.bossStyle;float dx=x-b.x,dy=y-b.y,d=(float)Math.hypot(dx,dy);if(style==0){if(bossPhase==1){if(d<sx(170)&&now>invulnUntil)takeDamage(13);for(int i=-1;i<=1;i++){float a=(float)(Math.atan2(dy,dx)+i*.22);projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*260,(float)Math.sin(a)*260,true,false,13));}}else{projectiles.add(new Projectile(b.x,b.y,dx/(d+.01f)*520,dy/(d+.01f)*520,true,true,25));b.x+=dx/(d+.01f)*80;b.y+=dy/(d+.01f)*80;}}else if(style==1){int count=bossPhase==1?10:16;for(int i=0;i<count;i++){double a=i*Math.PI*2/count;projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*190,(float)Math.sin(a)*190,true,bossPhase==2,12+chapter*3));}for(int i=0;i<(bossPhase==2?4:2);i++){float px=x+(rng.nextFloat()-.5f)*sx(420),py=y+(rng.nextFloat()-.5f)*sy(280);projectiles.add(new Projectile(px,py,0,0,true,true,20,now+900+i*250));}}else if(style==2){if(bossPhase==1){if(d<sx(180)&&now>invulnUntil)takeDamage(22);for(int i=0;i<6;i++){double a=i*Math.PI/3;projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*150,(float)Math.sin(a)*150,true,true,18));}}else{for(int i=0;i<3;i++){float a=(float)(Math.atan2(dy,dx)+(i-1)*.32);projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*360,(float)Math.sin(a)*360,true,true,28));}if(d<sx(260)&&now>invulnUntil)takeDamage(32);}}else if(style==3){b.x=sx(130)+rng.nextFloat()*W*.74f;b.y=sy(230)+rng.nextFloat()*H*.25f;int n=bossPhase==1?3:6;for(int i=0;i<n;i++){double a=rng.nextDouble()*Math.PI*2;projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*240,(float)Math.sin(a)*240,true,false,15));}}else{int mode=(int)((now/700)%4);if(bossPhase==1){if(mode==0){for(int i=0;i<8;i++){double a=i*Math.PI/4;projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*230,(float)Math.sin(a)*230,true,false,16));}}else if(mode==1)projectiles.add(new Projectile(b.x,b.y,dx/(d+.01f)*470,dy/(d+.01f)*470,true,true,25));else if(mode==2){for(int i=0;i<5;i++){double a=Math.atan2(dy,dx)+(i-2)*.18;projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*300,(float)Math.sin(a)*300,true,false,18));}}else if(d<sx(230)&&now>invulnUntil)takeDamage(24);}else{for(int i=0;i<12;i++){double a=i*Math.PI/6+now*.0003;projectiles.add(new Projectile(b.x,b.y,(float)Math.cos(a)*270,(float)Math.sin(a)*270,true,true,20));}if(now>invulnUntil&&d<sx(300))takeDamage(30);}}beep(110+style*35,70);}

    void takeDamage(float dmg){long now=System.currentTimeMillis();if(adminHealth){hp=maxHp;return;}if(now<invulnUntil)return;if(now<shieldUntil){shieldUntil=0;invulnUntil=now+220;fx.add(new Fx(x,y,now,300,65,100,190,255));return;}hp-=dmg;hurtUntil=now+240;flash=now+100;fx.add(new Fx(x,y,now,180,30,220,70,80));beep(95,45);if(hp<=0){deaths++;saveAll();screen=GAMEOVER;}}
    void clampPlayer(){
        if(adminFreeWorld)return;
        x=Math.max(sx(55),Math.min(W-sx(55),x));
        y=Math.max(sy(190),Math.min(H-sy(300),y));
    }
    boolean outsideWorld(){
        return x<sx(0) || x>W || y<sy(100) || y>H-sy(210);
    }
    void beep(int f,int d){try{if(tone!=null)tone.startTone(ToneGenerator.TONE_PROP_BEEP2,Math.min(d,300));}catch(Exception ignored){}}

    Runnable tick=new Runnable(){public void run(){update();postDelayed(this,16);}};

    static class Enemy{float x,y,hp,max,speed;int kind,bossStyle;boolean boss,elite;long attackCd,attackAnim,stunUntil,freezeUntil,markUntil,pullUntil;float pullX,pullY;}
    static class Projectile{float x,y,vx,vy,damage,life=4f;boolean enemy,big;long birth=System.currentTimeMillis(),delay=0;Projectile(float X,float Y,float Vx,float Vy,boolean E,boolean B,float D){x=X;y=Y;vx=Vx;vy=Vy;enemy=E;big=B;damage=D;}Projectile(float X,float Y,float Vx,float Vy,boolean E,boolean B,float D,long expire){this(X,Y,Vx,Vy,E,B,D);delay=Math.max(0,expire-birth);}}
    static class Fx{float x,y,size;long birth,life;int colorR,colorG,colorB;Fx(float X,float Y,long B,long L,float S,int R,int G,int Bl){x=X;y=Y;birth=B;life=L;size=S;colorR=R;colorG=G;colorB=Bl;}}
    static class Loot{float x,y;int type;boolean taken;Loot(float X,float Y,int T){x=X;y=Y;type=T;}}
}
